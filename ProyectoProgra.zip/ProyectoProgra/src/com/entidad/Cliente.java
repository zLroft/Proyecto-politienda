
package com.entidad;

public class Cliente {
    private String nombreCliente;
    private String cedulaCliente;
    public String usuarioCliente;
    public String contraseniaCliente;

    public Cliente(String nombre, String cedula, String usuario, String contras) {
        this.nombreCliente = nombre;
        this.cedulaCliente = cedula;
        this.usuarioCliente = usuario;
        this.contraseniaCliente = contras;
    }

    public Cliente() {
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getCedulaCliente() {
        return cedulaCliente;
    }

    public void setCedulaCliente(String cedulaCliente) {
        this.cedulaCliente = cedulaCliente;
    }

    public String getUsuarioCliente() {
        return usuarioCliente;
    }

    public void setUsuarioCliente(String usuarioCliente) {
        this.usuarioCliente = usuarioCliente;
    }

    public String getContraseniaCliente() {
        return contraseniaCliente;
    }

    public void setContraseniaCliente(String contraseniaCliente) {
        this.contraseniaCliente = contraseniaCliente;
    }
    
    public boolean login(String usuario, String contrasena) {
        return this.usuarioCliente.equals(usuario) && this.contraseniaCliente.equals(contrasena);
    }    

    public String toCSV() {
        return cedulaCliente + "," + nombreCliente;
    }    
    
    @Override
    public String toString() {
        return "Cliente" 
                + "\nNombre:" + nombreCliente 
                + "\nCedula:" + cedulaCliente;
    }
    
}
