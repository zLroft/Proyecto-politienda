
package com.entidad;

public class Producto {
    public String nombreProducto;
    public String idProducto;
    public double precio;
    public int stock;

    public Producto(String nombrep, String id, double precio, int stock) {
        this.nombreProducto = nombrep;
        this.idProducto = id;
        this.precio = precio;
        this.stock = stock;
    }

    public Producto() {
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
    public void agregarStock(int cantidad){
        stock=stock+cantidad;
    }
    
    public boolean reducirStock(int cantidad){
        if (cantidad <= stock) {
            stock -= cantidad;
            return true;
        }
        return false;        
    }
    
    
    public String toCSV() {
        return idProducto + "," + nombreProducto + "," + precio + "," + stock;
    }

    @Override
    public String toString() {
        return "Producto" 
                + "\nNombre: " + nombreProducto 
                + "\nCodigo: " + idProducto 
                + "\nPrecio: " + precio 
                + "\nStock: " + stock 
                + "\n";
    }
 
}
