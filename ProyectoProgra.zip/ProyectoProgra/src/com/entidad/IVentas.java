
package com.entidad;

public interface IVentas {
    void calcularPrecio();
    
}
