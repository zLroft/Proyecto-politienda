
package com.entidad;

public class Venta extends Producto implements IVentas{
    public int cantidad;
    public double ventas;

    public Venta(String nombrep, String id, double precio, int stock) {
        super(nombrep, id, precio, stock);
        this.cantidad = cantidad;
        this.ventas = ventas;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getVentas() {
        return ventas;
    }

    public void setVentas(double ventas) {
        this.ventas = ventas;
    }
    
    @Override
    public void calcularPrecio() {
        ventas=cantidad*precio;
    }
}
