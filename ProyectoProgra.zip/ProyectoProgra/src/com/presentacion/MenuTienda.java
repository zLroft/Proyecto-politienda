
package com.presentacion;

import com.entidad.Venta;
import com.negocio.Datos;
import com.negocio.GestionTienda;
import javax.swing.table.DefaultTableModel;

public class MenuTienda extends javax.swing.JInternalFrame {
    private GestionTienda gestionTienda=new GestionTienda();
    public MenuTienda() {
        initComponents();
        cargarProductos();
    }
    
    private void cargarProductos() {
    DefaultTableModel modelo = (DefaultTableModel) jTVenta.getModel();
    modelo.setRowCount(0); 

    for (Venta venta : Datos.DatosCompartidos.listaVentas) {
        modelo.addRow(new Object[]{
            venta.getIdProducto(), venta.getNombreProducto(), venta.getPrecio(), venta.getStock()
        });
    }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPTienda = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTVenta = new javax.swing.JTable();

        setPreferredSize(new java.awt.Dimension(681, 430));

        jPTienda.setBackground(new java.awt.Color(204, 204, 204));

        jTVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Productos", "Id", "Precio", "En stock"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTVenta);

        javax.swing.GroupLayout jPTiendaLayout = new javax.swing.GroupLayout(jPTienda);
        jPTienda.setLayout(jPTiendaLayout);
        jPTiendaLayout.setHorizontalGroup(
            jPTiendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPTiendaLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 95, Short.MAX_VALUE))
        );
        jPTiendaLayout.setVerticalGroup(
            jPTiendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPTiendaLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 14, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPTienda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPTienda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPTienda;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTVenta;
    // End of variables declaration//GEN-END:variables
}
