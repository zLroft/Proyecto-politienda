
package com.negocio;
import com.entidad.Empleado;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class GestionEmpleado  {
    private List<Empleado> listaEmpleados;
    String salida="";

    public GestionEmpleado() {
        listaEmpleados = new ArrayList<>();
        listaEmpleados.add(new Empleado("Juan", "1723456789", "juan", "1234"));
    }

    public Empleado autenticar(String usuario, String contrasena) {
        for (Empleado e : listaEmpleados) {
            if (e.getUsuarioEmpleado().equals(usuario) && e.getContraseniaEmpleado().equals(contrasena)) {
                return e;
            }
        }
        return null;
    }
    
    public void agregarEmpleado(Empleado empleado){
        listaEmpleados.add(empleado);
    }

    public List<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }
    
    public String mostrarEmpleado(){
        for(Empleado e:listaEmpleados){
            return e.toString();
        }
        return null;
    }
    
    public void guardarEmpleadoEnArchivo(Empleado empleado) {
    try (FileWriter fw = new FileWriter("clientes.csv", true);
         PrintWriter pw = new PrintWriter(fw)) {

        pw.println(empleado.getNombreEmpleado() + "," + empleado.getCedulaEmpleado());

    } catch (IOException e) {
        System.out.println("Error al guardar empleado: " + e.getMessage());
    }
}
    
    public void cargarEmpleadosDesdeArchivo() {
    listaEmpleados.clear(); 
    try (BufferedReader br = new BufferedReader(new FileReader("clientes.csv"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] partes = linea.split(",");
            Empleado empleado = new Empleado(partes[0], partes[1], partes[2],partes[3]);
            listaEmpleados.add(empleado);
        }
    } catch (IOException e) {
        System.out.println("Error al cargar clientes: " + e.getMessage());
    }
}


}
