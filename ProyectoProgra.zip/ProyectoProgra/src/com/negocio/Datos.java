
package com.negocio;

import com.entidad.Venta;
import java.util.ArrayList;

public class Datos {
    public class DatosCompartidos {
    public static ArrayList<Venta> listaVentas = new ArrayList<>();
}

}
