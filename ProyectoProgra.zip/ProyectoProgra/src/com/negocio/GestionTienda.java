package com.negocio;

import com.entidad.Cliente;
import com.entidad.Venta;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class GestionTienda {
    private List<Venta> listaProducto;
    String salida="";

    public GestionTienda() {
        this.listaProducto = new ArrayList<>();
    }

    public List<Venta> getListaProducto() {
        return listaProducto;
    }

    public void setListaProducto(List<Venta> listaProducto) {
        this.listaProducto = listaProducto;
    }
    
    public void agregarProducto(Venta venta){
        listaProducto.add(venta);
    }

    public String mostrarProductos(){
        for(Venta v: listaProducto){
            salida+=v.toString();
            
        }
        return salida;
    }
    
    public void eliminarProducto(Venta venta){
        listaProducto.remove(venta);
    }
    
    public boolean reducir(String id,int cantidad){
        for(Venta v:listaProducto){
            if(v.getIdProducto().equals(id)){
            v.reducirStock(cantidad);
            return true;
        }
        }return false;
    }
    
    public boolean agregar(String id,int cantidad){
        for(Venta v:listaProducto){
            if(v.getIdProducto().equals(id)){
            v.agregarStock(cantidad);
            return true;
        }
        }
        return false;
    }
    
    public void guardarProductoEnArchivo(Venta venta) {
    try (FileWriter fw = new FileWriter("clientes.csv", true);
         PrintWriter pw = new PrintWriter(fw)) {

        pw.println(venta.nombreProducto + "," + venta.idProducto + "," + venta.precio+ "," + venta.stock);

    } catch (IOException e) {
        System.out.println("Error al guardar producto: " + e.getMessage());
    }
}
public void cargarProductosDesdeArchivo() {
    listaProducto.clear(); // Limpiar antes de cargar
    try (BufferedReader br = new BufferedReader(new FileReader("clientes.csv"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] partes = linea.split(",");
            Venta ven = new Venta(partes[0], partes[1],Double.parseDouble(partes[2]),Integer.parseInt(partes[3])); 
            listaProducto.add(ven);
        }
    } catch (IOException e) {
        System.out.println("Error al cargar producto: " + e.getMessage());
    }
}

    
}
    
