
package com.negocio;

import com.entidad.Cliente;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class GestionClientes {
    private List<Cliente> listaClientes;

    public GestionClientes() {
        this.listaClientes = new ArrayList<>();
        listaClientes.add(new Cliente("Pedro", "172923910", "pepe", "2020"));
    }

    public List<Cliente> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(List<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }

    public Cliente autenticar(String usuario, String contrasena) {
        for (Cliente c:listaClientes) {
            if (c.getUsuarioCliente().equals(usuario) && c.getContraseniaCliente().equals(contrasena)) {
                return c;
            }
        }
        return null;
    }

    public void agregarCliente(Cliente cliente){
        listaClientes.add(cliente);
    }    
    
    public String mostrarCliente(){
        for(Cliente c:listaClientes){
          return c.toString();
        }
        return null;
    }
    
    public void guardarClienteEnArchivo(Cliente cliente) {
    try (FileWriter fw = new FileWriter("clientes.csv", true);
         PrintWriter pw = new PrintWriter(fw)) {

        pw.println(cliente.getNombreCliente()+ "," + cliente.getCedulaCliente());

    } catch (IOException e) {
        System.out.println("Error al guardar cliente: " + e.getMessage());
    }
}
    public void cargarClientesDesdeArchivo() {
    listaClientes.clear(); // Limpiar antes de cargar
    try (BufferedReader br = new BufferedReader(new FileReader("clientes.csv"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] partes = linea.split(",");
            Cliente cliente = new Cliente(partes[0], partes[1], partes[2],partes[3]); 
            listaClientes.add(cliente);
        }
    } catch (IOException e) {
        System.out.println("Error al cargar clientes: " + e.getMessage());
    }
}


}
