
package com.entidad;

public class Venta extends Producto implements IVentas{
    private Cliente cliente=new Cliente();
    public int cantidad;
    public double total;

    public Venta(String nombrep, String id, double precio, int stock) {
        super(nombrep, id, precio, stock);
        this.cantidad = cantidad;
        this.total = total;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    @Override
    public void calcularPrecio() {
        total=cantidad;
    }
    
    public void pago(){
         ;
    }
}
