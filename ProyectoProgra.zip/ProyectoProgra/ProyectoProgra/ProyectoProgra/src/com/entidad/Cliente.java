package com.entidad;

public class Cliente {
    private String nombreCliente;
    private String cedulaCliente;
    private String usuarioCliente;
    private String contraseniaCliente;
    private double saldo;

    public Cliente(String nombreCliente, String cedulaCliente, String usuarioCliente, String contraseniaCliente, double saldo) {
        this.nombreCliente = nombreCliente;
        this.cedulaCliente = cedulaCliente;
        this.usuarioCliente = usuarioCliente;
        this.contraseniaCliente = contraseniaCliente;
        this.saldo = saldo;
    }

    public Cliente() {
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getCedulaCliente() {
        return cedulaCliente;
    }

    public void setCedulaCliente(String cedulaCliente) {
        this.cedulaCliente = cedulaCliente;
    }

    public String getUsuarioCliente() {
        return usuarioCliente;
    }

    public void setUsuarioCliente(String usuarioCliente) {
        this.usuarioCliente = usuarioCliente;
    }

    public String getContraseniaCliente() {
        return contraseniaCliente;
    }

    public void setContraseniaCliente(String contraseniaCliente) {
        this.contraseniaCliente = contraseniaCliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void agregarSaldo(double monto) {
        if (monto > 0) {
            this.saldo += monto;
        }
    }

    public boolean descontarSaldo(double monto) {
        if (monto > 0 && monto <= saldo) {
            this.saldo -= monto;
            return true;
        }
        return false;
    }

    public boolean autenticar(String usuario, String clave) {
        return this.usuarioCliente.equals(usuario) && this.contraseniaCliente.equals(clave);
    }
}
