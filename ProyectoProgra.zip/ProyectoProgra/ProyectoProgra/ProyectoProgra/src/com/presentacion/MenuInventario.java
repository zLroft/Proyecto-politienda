package com.presentacion;

import com.entidad.Venta;
import com.negocio.GestionEmpleado;
import com.negocio.GestionTienda;

import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;

/*
 * Clase que representa la interfaz interna para gestionar el inventario de productos.
 * Esta clase se enfoca en la presentación (UI) y delega la lógica de negocio a las clases GestionTienda y GestionEmpleado.
 */
public class MenuInventario extends javax.swing.JInternalFrame {

    // Instancias de las clases que gestionan la lógica de tienda y empleados
    private GestionTienda gestionTienda = new GestionTienda();
    private GestionEmpleado gestionEmpleado = new GestionEmpleado();

    // Modelo de tabla para mostrar los productos en la interfaz
    private DefaultTableModel tablaProductos = new DefaultTableModel();

    /*
     * Constructor que inicializa los componentes gráficos y carga los datos necesarios.
     */
    public MenuInventario() {
        initComponents();

        // Eliminar bordes y panel superior (barra de título) del JInternalFrame para diseño personalizado
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);

        // Definir las columnas que tendrá la tabla de productos
        String ids[] = {"Nombre", "ID", "Precio", "Stock"};
        tablaProductos.setColumnIdentifiers(ids);

        // Asignar el modelo de tabla al JTable de la interfaz
        jTProductos.setModel(tablaProductos);

        // Cargar los productos almacenados desde archivo para poblar la lista
        gestionTienda.cargarProductosDesdeArchivo();

        // Actualizar la tabla gráfica con los productos cargados
        actualizarTabla();
    }

    /*
     * Actualiza el contenido de la tabla de productos con la información actual.
     * Limpia las filas previas y agrega las filas correspondientes a cada producto en la lista.
     */
    private void actualizarTabla() {
        tablaProductos.setRowCount(0); // Eliminar todas las filas actuales

        // Recorrer la lista de productos y agregarlos como filas a la tabla
        for (Venta producto : gestionTienda.getListaProducto()) {
            Object[] fila = {
                producto.getNombreProducto(),
                producto.getIdProducto(),
                producto.getPrecio(),
                producto.getStock()
            };
            tablaProductos.addRow(fila);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTFNombrep = new javax.swing.JTextField();
        jTFStock = new javax.swing.JTextField();
        jTFPrecio = new javax.swing.JTextField();
        jBRegistrar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTProductos = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTAInformacion = new javax.swing.JTextArea();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setPreferredSize(new java.awt.Dimension(760, 480));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Registrar producto", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Yu Gothic UI Semibold", 0, 18))); // NOI18N
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel2.setText("Nombre:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 22, 80, -1));

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel4.setText("Precio:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 60, -1));

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel5.setText("Stock:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));

        jTFNombrep.setBackground(new java.awt.Color(0, 0, 0));
        jTFNombrep.setForeground(new java.awt.Color(255, 255, 255));
        jTFNombrep.setBorder(null);
        jPanel2.add(jTFNombrep, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 170, 30));

        jTFStock.setBackground(new java.awt.Color(0, 0, 0));
        jTFStock.setForeground(new java.awt.Color(255, 255, 255));
        jTFStock.setBorder(null);
        jPanel2.add(jTFStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 170, 30));

        jTFPrecio.setBackground(new java.awt.Color(0, 0, 0));
        jTFPrecio.setForeground(new java.awt.Color(255, 255, 255));
        jTFPrecio.setBorder(null);
        jTFPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFPrecioActionPerformed(evt);
            }
        });
        jPanel2.add(jTFPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 170, 30));

        jBRegistrar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jBRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/agregar.png"))); // NOI18N
        jBRegistrar.setText("Registrar");
        jBRegistrar.setBorder(null);
        jBRegistrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBRegistrar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBRegistrar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBRegistrarActionPerformed(evt);
            }
        });
        jPanel2.add(jBRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 30, 80, 100));

        jButton1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/edit.png"))); // NOI18N
        jButton1.setText("Editar");
        jButton1.setBorder(null);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 80, 80, -1));

        jButton2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/diskette.png"))); // NOI18N
        jButton2.setText("Guardar ");
        jButton2.setBorder(null);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 140, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 470, 260));

        jTProductos.setBackground(new java.awt.Color(204, 204, 204));
        jTProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre", "ID", "Precio", "Stock"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTProductosMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTProductos);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 750, 170));

        jTAInformacion.setEditable(false);
        jTAInformacion.setColumns(20);
        jTAInformacion.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTAInformacion.setRows(5);
        jTAInformacion.setBorder(null);
        jScrollPane1.setViewportView(jTAInformacion);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 20, 280, 260));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBRegistrarActionPerformed
// Obtener valores de los campos de texto, eliminando espacios en blanco al inicio y fin
    String nombreProducto = jTFNombrep.getText().trim();
    String precio = jTFPrecio.getText().trim();
    String stock = jTFStock.getText().trim();

// Validar que no haya campos vacíos
    if (nombreProducto.isEmpty() || precio.isEmpty() || stock.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Llenar todos los campos");
    return; // Detener ejecución si hay campos vacíos
    }

    double preciop;
    int stockProducto;

// Validar que precio y stock sean números válidos
    try {
    preciop = Double.parseDouble(precio);
    stockProducto = Integer.parseInt(stock);
    } catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser valores numéricos válidos", "Error", JOptionPane.ERROR_MESSAGE);
    return;
    }

// Validar que precio y cantidad sean mayores que cero
    if (preciop <= 0 || stockProducto <= 0) {
    JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser mayores que 0", "Error", JOptionPane.ERROR_MESSAGE);
    return;
    }

// Generar ID para el producto con formato 4 dígitos (ej: 0001, 0002...)
    String idGenerado = String.format("%04d", gestionTienda.getListaProducto().size() + 1);

// Crear nuevo objeto Venta con los datos ingresados
    Venta venta = new Venta(nombreProducto, idGenerado, preciop, stockProducto);

// Verificar si el producto ya existe (por ID o nombre)
// Si retorna false, significa que ya existe y muestra mensaje internamente
    if (!gestionTienda.verificarExistencia(venta)) {
    return; // Detener para evitar agregar duplicados
}

// Agregar producto a la lista en memoria
    gestionTienda.agregarProducto(venta);

// Guardar producto en archivo para persistencia
    gestionTienda.guardarProductoEnArchivo(venta);

// Actualizar área de texto con los productos actuales
    jTAInformacion.setText(gestionTienda.mostrarProductos());

// Mostrar mensaje de éxito al usuario
    JOptionPane.showMessageDialog(this, "Producto agregado al inventario");

// Actualizar la tabla en la interfaz (asumo que tienes método para eso)
    actualizarTabla();

// Limpiar campos de entrada para nueva captura
    jTFNombrep.setText("");
    jTFPrecio.setText("");
    jTFStock.setText("");

    }//GEN-LAST:event_jBRegistrarActionPerformed

    private void jTFPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFPrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFPrecioActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int filaSeleccionada = jTProductos.getSelectedRow(); // fila seleccionada

        if (filaSeleccionada >= 0) {
            jTFNombrep.setText(tablaProductos.getValueAt(filaSeleccionada, 0).toString());
            jTFPrecio.setText(tablaProductos.getValueAt(filaSeleccionada, 2).toString());
            jTFStock.setText(tablaProductos.getValueAt(filaSeleccionada, 3).toString());
        }     
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTProductosMouseClicked

    }//GEN-LAST:event_jTProductosMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int filaSeleccionada = jTProductos.getSelectedRow();
        if (filaSeleccionada >= 0) {
            // Obtener datos modificados desde los JTextField
        String nombreProducto = jTFNombrep.getText().trim();
        String precio = jTFPrecio.getText().trim();
        String stock = jTFStock.getText().trim();
        String codigo = tablaProductos.getValueAt(filaSeleccionada, 0).toString();

            // Actualizar tabla visualmente
            tablaProductos.setValueAt(nombreProducto, filaSeleccionada, 0);
            tablaProductos.setValueAt(precio, filaSeleccionada, 2);
            tablaProductos.setValueAt(stock, filaSeleccionada, 3);
            
        double preciop;
        int stockProducto;

        try {
            preciop = Double.parseDouble(precio);
            stockProducto = Integer.parseInt(stock);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser valores numéricos válidos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (preciop <= 0 || stockProducto <= 0) {
            JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser mayores que 0", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
            // Guardar en archivo CSV
            gestionTienda.guardarTodosLosProductos();

            JOptionPane.showMessageDialog(null, "¡Producto actualizado correctamente!");
        } else {
            JOptionPane.showMessageDialog(null, "Selecciona una fila primero.");
        }
    
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBRegistrar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTAInformacion;
    private javax.swing.JTextField jTFNombrep;
    private javax.swing.JTextField jTFPrecio;
    private javax.swing.JTextField jTFStock;
    private javax.swing.JTable jTProductos;
    // End of variables declaration//GEN-END:variables

}
