
package com.presentacion;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

public class JFOpciones extends javax.swing.JFrame {
        private FondoPanel fondo = new FondoPanel();

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JFOpciones.class.getName());

    public JFOpciones() {
        this.setContentPane(fondo);
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jBCliente = new javax.swing.JButton();
        jBEmpleado = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Como desea registrarse");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 260, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen2.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-110, -270, -1, -1));

        jBCliente.setBackground(new java.awt.Color(0, 153, 102));
        jBCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jBCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/client.png"))); // NOI18N
        jBCliente.setText("Cliente");
        jBCliente.setBorder(null);
        jBCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBCliente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBCliente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBClienteActionPerformed(evt);
            }
        });
        getContentPane().add(jBCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 380, 160, 110));

        jBEmpleado.setBackground(new java.awt.Color(255, 102, 0));
        jBEmpleado.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jBEmpleado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/organization.png"))); // NOI18N
        jBEmpleado.setText("Empleado");
        jBEmpleado.setBorder(null);
        jBEmpleado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBEmpleado.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBEmpleado.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBEmpleadoActionPerformed(evt);
            }
        });
        getContentPane().add(jBEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 70, 160, 110));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBClienteActionPerformed
       JFRegistrarCliente jcli=new JFRegistrarCliente();
       jcli.setVisible(rootPaneCheckingEnabled);
       this.dispose();
    }//GEN-LAST:event_jBClienteActionPerformed

    private void jBEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBEmpleadoActionPerformed
       JFRegistrarEmpleado jemp=new JFRegistrarEmpleado();
       jemp.setVisible(rootPaneCheckingEnabled);
       this.dispose();
    }//GEN-LAST:event_jBEmpleadoActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new JFOpciones().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBCliente;
    private javax.swing.JButton jBEmpleado;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
class FondoPanel extends javax.swing.JPanel {
    private Image imagen;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        imagen = new ImageIcon(getClass().getResource("/imagenes/Fondo2.png")).getImage(); // Reemplaza con tu ruta
        g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
    }
}
}
