package com.presentacion;

import com.negocio.GestionTienda;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;

/*
 * Clase que representa la interfaz interna para gestionar la tienda y mostrar productos disponibles para venta.
 * Se encarga exclusivamente de la presentación y delega la lógica a GestionTienda.
 */
public class MenuTienda extends javax.swing.JInternalFrame {

    // Instancia que gestiona la lógica y datos de la tienda
    private GestionTienda gestionTienda = new GestionTienda();

    // Modelo para la tabla que mostrará los productos en la UI
    private DefaultTableModel tablaProductos = new DefaultTableModel();

    /*
     * Constructor que inicializa los componentes gráficos y carga los productos desde archivo.
     */
    public MenuTienda() {
        initComponents();

        // Eliminar bordes y panel superior para personalización del JInternalFrame
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);

        // Definir las columnas que tendrá la tabla de productos
        String[] columnas = {"Nombre", "ID", "Precio", "Stock"};
        tablaProductos.setColumnIdentifiers(columnas);

        // Asignar el modelo al JTable en la interfaz
        jTVenta.setModel(tablaProductos);

        // Cargar productos almacenados para mostrar en la tabla
        gestionTienda.cargarProductosDesdeArchivo();

        // Actualizar la tabla con los datos cargados
        actualizarTabla();
    }

    /*
     * Método para actualizar la tabla con los productos actuales.
     * Limpia las filas existentes y agrega una fila por cada producto.
     */
    private void actualizarTabla() {
        tablaProductos.setRowCount(0); // Limpiar filas existentes

        // Recorrer productos y agregarlos como filas en la tabla
        for (var producto : gestionTienda.getListaProducto()) {
            Object[] fila = {
                producto.getNombreProducto(),
                producto.getIdProducto(),
                producto.getPrecio(),
                producto.getStock()
            };
            tablaProductos.addRow(fila);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTVenta = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jBComprar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();

        jButton1.setText("jButton1");

        setBorder(null);
        setPreferredSize(new java.awt.Dimension(760, 480));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Productos", "Id", "Precio", "En stock"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTVenta);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, 250));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jBComprar.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jBComprar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Pedido.png"))); // NOI18N
        jBComprar.setText("Agregar ");
        jBComprar.setBorder(null);
        jBComprar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBComprar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBComprar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBComprarActionPerformed(evt);
            }
        });
        jPanel1.add(jBComprar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 30, -1, -1));

        jLabel2.setText("Cantidad:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 50, 30));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 130, 30));

        jLabel3.setText("Total:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 30, 30));

        jScrollPane2.setBorder(null);
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane2.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 130, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 470, 210));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("jLabel1");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jTextArea2.setEditable(false);
        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jTextArea2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane3.setViewportView(jTextArea2);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 290, 210));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 0, 290, 460));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBComprarActionPerformed
        
    }//GEN-LAST:event_jBComprarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBComprar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTVenta;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
