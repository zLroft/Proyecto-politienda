
package com.presentacion;

import com.entidad.Venta;
import com.negocio.GestionEmpleado;
import com.negocio.GestionTienda;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;

public class MenuStock extends javax.swing.JInternalFrame {

    private GestionTienda gestionTienda=new GestionTienda();
    private GestionEmpleado gestionEmpleado=new GestionEmpleado();
    DefaultTableModel tablaProductos=new DefaultTableModel();
    public MenuStock() {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        BasicInternalFrameUI ui=(BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
        String ids[]={"Nombre","ID","Precio","Stock"};
        tablaProductos.setColumnIdentifiers(ids);
        jTProductos.setModel(tablaProductos);
        gestionTienda.cargarProductosDesdeArchivo();
        actualizarTabla();
    }
    
    private void actualizarTabla() {
    tablaProductos.setRowCount(0); 

    for (var producto : gestionTienda.getListaProducto()) {
        Object[] fila = {producto.getNombreProducto(), producto.getIdProducto(), producto.getPrecio(), producto.getStock()};
        tablaProductos.addRow(fila);
    }
}  

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTFNumeroID = new javax.swing.JTextField();
        jTFCantidads = new javax.swing.JTextField();
        jBAgregarStock = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTProductos = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setPreferredSize(new java.awt.Dimension(760, 480));

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos del producto", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18))); // NOI18N
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("ID:");
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("Cantidad:");
        jPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        jTFNumeroID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPanel4.add(jTFNumeroID, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 200, 30));

        jTFCantidads.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPanel4.add(jTFCantidads, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 200, 30));

        jBAgregarStock.setBackground(new java.awt.Color(204, 204, 204));
        jBAgregarStock.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jBAgregarStock.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/add-to-basket (1).png"))); // NOI18N
        jBAgregarStock.setText("Agregar stock");
        jBAgregarStock.setBorder(null);
        jBAgregarStock.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBAgregarStock.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBAgregarStock.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBAgregarStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAgregarStockActionPerformed(evt);
            }
        });
        jPanel4.add(jBAgregarStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, 150, -1));

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/delete (1).png"))); // NOI18N
        jButton1.setText("Eliminar producto");
        jButton1.setBorder(null);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, -1, -1));

        jTProductos.setBackground(new java.awt.Color(204, 204, 204));
        jTProductos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre", "ID", "Precio", "Stock"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTProductos.setCursor(new java.awt.Cursor(java.awt.Cursor.MOVE_CURSOR));
        jScrollPane3.setViewportView(jTProductos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 524, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(230, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBAgregarStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAgregarStockActionPerformed
        String idProducto = jTFNumeroID.getText().trim();
        String cantidad = jTFCantidads.getText().trim();

        if (idProducto.isEmpty() || cantidad.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Llenar todos los campos");
            return;
        }

        int stock;

        try {
            stock = Integer.parseInt(cantidad);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Cantidad debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (stock <= 0) {
            JOptionPane.showMessageDialog(this, "Cantidad debe ser mayor que 0", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean encontrado = gestionTienda.agregar(idProducto, stock);

        if (encontrado) {
            JOptionPane.showMessageDialog(this, "Stock actualizado correctamente");
            actualizarTabla();
        } else {
            JOptionPane.showMessageDialog(this, "Producto no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
        }

        jTFNumeroID.setText("");
        jTFCantidads.setText("");
    }//GEN-LAST:event_jBAgregarStockActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    int filaSeleccionada = jTProductos.getSelectedRow();

    if (filaSeleccionada >= 0) {
        int confirm = JOptionPane.showConfirmDialog(this, "¿Deseas eliminar este producto?", "Confirmar", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Obtener los datos de la fila seleccionada
            String idProducto = tablaProductos.getValueAt(filaSeleccionada, 1).toString(); // Columna ID

            // Buscar el objeto Venta en la lista
            Venta productoAEliminar = null;
            for (Venta v : gestionTienda.getListaProducto()) {
                if (v.getIdProducto().equals(idProducto)) {
                    productoAEliminar = v;
                    break;
                }
            }

            if (productoAEliminar != null) {
                // Eliminar usando el método de GestionTienda
                gestionTienda.eliminarProducto(productoAEliminar);

                // Quitar de la tabla visual
                DefaultTableModel modelo = (DefaultTableModel) jTProductos.getModel();
                modelo.removeRow(filaSeleccionada);
                JOptionPane.showMessageDialog(this, "Producto eliminado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el producto.");
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Selecciona un producto para eliminar.");
    }
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBAgregarStock;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTFCantidads;
    private javax.swing.JTextField jTFNumeroID;
    private javax.swing.JTable jTProductos;
    // End of variables declaration//GEN-END:variables

}
