
package com.presentacion;

import com.entidad.Cliente;
import com.entidad.Empleado;
import com.negocio.GestionClientes;
import com.negocio.GestionEmpleado;
import com.negocio.SesionActual;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class Login extends javax.swing.JFrame {
    private GestionEmpleado gestionEmpleado=new GestionEmpleado();
    private GestionClientes gestionClientes=new GestionClientes();
    private FondoPanel fondo = new FondoPanel();
    private SesionActual sesionActual=new SesionActual();
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Login.class.getName());

    public Login() {
        this.setContentPane(fondo);
        initComponents();
        gestionClientes.cargarClientesDesdeArchivo();
        gestionEmpleado.cargarEmpleadosDesdeArchivo();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTFUsuario = new javax.swing.JTextField();
        jPFContra = new javax.swing.JPasswordField();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jCBInicio = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Politienda login");
        setPreferredSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/group.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 0, 100, 100));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/user.png"))); // NOI18N
        jLabel3.setText("Usuario");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 100, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/padlock.png"))); // NOI18N
        jLabel4.setText("Contraseña");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, -1));

        jTFUsuario.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        jTFUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFUsuarioActionPerformed(evt);
            }
        });
        jPanel2.add(jTFUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 250, 40));

        jPFContra.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        jPanel2.add(jPFContra, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, 250, 40));

        jPanel1.setBackground(new java.awt.Color(204, 102, 0));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Hola.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(60, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(48, 48, 48))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(66, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(26, 26, 26))
        );

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 150));

        jPanel3.setBackground(new java.awt.Color(204, 102, 0));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel9.setText("No tienes cuenta");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        jLabel8.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 51, 204));
        jLabel8.setText("Registrate");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabel8AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 30, -1, -1));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 350, 90));

        jLabel7.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel7.setText("Ingresar como:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, 40));

        jCBInicio.setBackground(new java.awt.Color(0, 102, 0));
        jCBInicio.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jCBInicio.setForeground(new java.awt.Color(255, 255, 255));
        jCBInicio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Entrar como", "Empleado", "Cliente" }));
        jCBInicio.setToolTipText("");
        jCBInicio.setBorder(null);
        jCBInicio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jCBInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCBInicioActionPerformed(evt);
            }
        });
        jPanel2.add(jCBInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 340, 160, 40));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 40, 350, 490));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Logo1.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 546, 539));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCBInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCBInicioActionPerformed
        int opcion=jCBInicio.getSelectedIndex();
        switch (opcion) {
            case 1:
        String usuarioEmpleado=jTFUsuario.getText();
        String contraEmpleado=jPFContra.getText();

        if(usuarioEmpleado.isEmpty()||contraEmpleado.isEmpty()){
            JOptionPane.showMessageDialog(this, "Llenar los campos");
            return;
        }else if(usuarioEmpleado.isEmpty()){
            JOptionPane.showMessageDialog(this, "Colocar usuario");
            return;
        }else if(contraEmpleado.isEmpty()){
            JOptionPane.showMessageDialog(this, "Colocar contraseña");
            return;
        }
        try {
            Empleado emp = gestionEmpleado.autenticar(usuarioEmpleado, contraEmpleado);
            if (emp != null) {
                JOptionPane.showMessageDialog(this, "Bienvenido " + emp.getNombreEmpleado());
                sesionActual.empleadoLogueado=emp;
                JFDashboard jd = new JFDashboard();
                jd.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al iniciar sesión: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

            break;
            case 2:


        String usuarioCliente=jTFUsuario.getText();
        String contraCliente=jPFContra.getText();

        if(usuarioCliente.isEmpty()||contraCliente.isEmpty()){
            JOptionPane.showMessageDialog(this, "Llenar los campos");
            return;
        }else if(usuarioCliente.isEmpty()){
            JOptionPane.showMessageDialog(this, "Colocar usuario");
            return;
        }else if(contraCliente.isEmpty()){
            JOptionPane.showMessageDialog(this, "Colocar contraseña");
            return;
        }

        try {
            Cliente cliente = gestionClientes.autenticar(usuarioCliente, contraCliente);
            if (cliente != null) {
                JOptionPane.showMessageDialog(this, "Bienvenido " + cliente.getNombreCliente());
                sesionActual.clienteLogeado=cliente;
                JFDashTienda jt = new JFDashTienda();
                jt.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al iniciar sesión: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
            break;
            default:
            JOptionPane.showMessageDialog(this, "Por favor selecciona una opción válida");
        }
    }//GEN-LAST:event_jCBInicioActionPerformed

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        JFOpciones opc=new JFOpciones();
        opc.setVisible(rootPaneCheckingEnabled);
        this.dispose();
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel8AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel8AncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8AncestorAdded

    private void jTFUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFUsuarioActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> jCBInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPasswordField jPFContra;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField jTFUsuario;
    // End of variables declaration//GEN-END:variables
class FondoPanel extends javax.swing.JPanel {
    private Image imagen;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        imagen = new ImageIcon(getClass().getResource("/imagenes/Fondo2.png")).getImage(); // Reemplaza con tu ruta
        g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
    }
}


}
