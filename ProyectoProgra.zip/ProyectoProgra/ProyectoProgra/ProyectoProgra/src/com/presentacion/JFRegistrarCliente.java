
package com.presentacion;

import com.entidad.Cliente;
import com.negocio.GestionClientes;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class JFRegistrarCliente extends javax.swing.JFrame {
    private GestionClientes gestionCliente = new GestionClientes();
    private FondoPanel fondo = new FondoPanel();
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JFRegistrarCliente.class.getName());

   
    public JFRegistrarCliente() {
        this.setContentPane(fondo);
        initComponents(); 
        this.setLocationRelativeTo(null);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jNombreCliente = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jCedulaCliente = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jUsuarioCliente = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jContrasenaCliente = new javax.swing.JTextField();
        jRegistrarCliente = new javax.swing.JButton();
        jBRegresar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jTFSaldo = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Registro");
        setPreferredSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 102));
        jPanel1.setForeground(new java.awt.Color(255, 0, 51));
        jPanel1.setToolTipText("");
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setPreferredSize(new java.awt.Dimension(350, 490));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel1.setText("Nombre:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 80, -1));

        jNombreCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jNombreCliente.setBorder(null);
        jPanel1.add(jNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 290, 40));

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel2.setText("Cedula:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 80, -1));

        jCedulaCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jCedulaCliente.setBorder(null);
        jPanel1.add(jCedulaCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 290, 40));

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel3.setText("Usuario:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 80, -1));

        jUsuarioCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jUsuarioCliente.setBorder(null);
        jPanel1.add(jUsuarioCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 290, 40));

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel4.setText("Contraseña:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));
        jPanel1.add(jContrasenaCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 290, 40));

        jRegistrarCliente.setBackground(new java.awt.Color(0, 153, 102));
        jRegistrarCliente.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jRegistrarCliente.setForeground(new java.awt.Color(255, 255, 255));
        jRegistrarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/client.png"))); // NOI18N
        jRegistrarCliente.setText("Registrar ");
        jRegistrarCliente.setBorder(null);
        jRegistrarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jRegistrarCliente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jRegistrarCliente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jRegistrarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRegistrarClienteActionPerformed(evt);
            }
        });
        jPanel1.add(jRegistrarCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 490, 100, 50));

        jBRegresar.setBackground(new java.awt.Color(0, 153, 102));
        jBRegresar.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jBRegresar.setForeground(new java.awt.Color(255, 255, 255));
        jBRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/return.png"))); // NOI18N
        jBRegresar.setText("Regresar");
        jBRegresar.setBorder(null);
        jBRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBRegresar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBRegresar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(jBRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 490, 118, -1));

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel6.setText("Saldo Inicial:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, -1));

        jTFSaldo.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jTFSaldo.setBorder(null);
        jPanel1.add(jTFSaldo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 290, 40));

        jPanel2.setBackground(new java.awt.Color(255, 153, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Registro.png"))); // NOI18N
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 80));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 20, -1, 550));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Register.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRegistrarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRegistrarClienteActionPerformed
        String nombreCliente = jNombreCliente.getText(). trim();
        String cedulaCliente = jCedulaCliente.getText().trim();
        String usuarioCliente=jUsuarioCliente.getText().trim();
        String contrasenaCliente = jContrasenaCliente.getText().trim();
        String saldoInicial=jTFSaldo.getText();
        
    if (nombreCliente.isEmpty()||cedulaCliente.isEmpty()||usuarioCliente.isEmpty()||contrasenaCliente.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Llenar Nombre");
    return;
     }
        
    if (cedulaCliente.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Llenar Cedula");
    return;
    }
    
    if (contrasenaCliente.isEmpty()){
        JOptionPane.showMessageDialog(this, "No sea cojudo hpta");
        return ;
    }

    if (usuarioCliente.isEmpty()){
        JOptionPane.showMessageDialog(this, "No sea cojudo hpta");
        return ;
    }
    
        double dinero;

        try {
            dinero = Double.parseDouble(saldoInicial);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser valores numéricos válidos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (dinero <= 0 ) {
            JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser mayores que 0", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
    try {
        Cliente cliente=new Cliente(nombreCliente, cedulaCliente, usuarioCliente, contrasenaCliente,dinero);
        gestionCliente.agregarCliente(cliente);
        gestionCliente.guardarClienteEnArchivo(cliente);
        JOptionPane.showMessageDialog(this, "Cuenta creada con exito");
        Login log=new Login();
        log.setVisible(rootPaneCheckingEnabled);
        this.dispose();
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "No se pudo crear la cuenta", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}
        
    }//GEN-LAST:event_jRegistrarClienteActionPerformed

    private void jBRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBRegresarActionPerformed
        Login regreso=new Login();
        regreso.setVisible(rootPaneCheckingEnabled);
        this.dispose();        
    }//GEN-LAST:event_jBRegresarActionPerformed

  
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new JFRegistrarCliente().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBRegresar;
    private javax.swing.JTextField jCedulaCliente;
    private javax.swing.JTextField jContrasenaCliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField jNombreCliente;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jRegistrarCliente;
    private javax.swing.JTextField jTFSaldo;
    private javax.swing.JTextField jUsuarioCliente;
    // End of variables declaration//GEN-END:variables
class FondoPanel extends javax.swing.JPanel {
    private Image imagen;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        imagen = new ImageIcon(getClass().getResource("/imagenes/Fondo2.png")).getImage(); 
        g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
    }
}
}
