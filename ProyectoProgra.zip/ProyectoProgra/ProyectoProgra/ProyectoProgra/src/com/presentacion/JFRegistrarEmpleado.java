
package com.presentacion;

import com.entidad.Empleado;
import com.negocio.GestionEmpleado;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class JFRegistrarEmpleado extends javax.swing.JFrame {
    private GestionEmpleado gestionEmpleado=new GestionEmpleado();
    private FondoPanel fondo = new FondoPanel();
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JFRegistrarEmpleado.class.getName());

   
    public JFRegistrarEmpleado() {
        this.setContentPane(fondo);
        initComponents(); 
        this.setLocationRelativeTo(null);
        gestionEmpleado.cargarEmpleadosDesdeArchivo();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jNombreCliente = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jCedulaCliente = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jUsuarioCliente = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jContrasenaCliente = new javax.swing.JTextField();
        jRegistrarCliente = new javax.swing.JButton();
        jBRegresar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Registro");
        setPreferredSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 153, 0));
        jPanel1.setForeground(new java.awt.Color(255, 0, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(350, 490));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel1.setText("Nombre:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 80, -1));

        jNombreCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jNombreCliente.setBorder(null);
        jPanel1.add(jNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 290, 40));

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel2.setText("Cedula:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 70, -1));

        jCedulaCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jCedulaCliente.setBorder(null);
        jPanel1.add(jCedulaCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 290, 40));

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel3.setText("Usuario:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 70, -1));

        jUsuarioCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jUsuarioCliente.setBorder(null);
        jPanel1.add(jUsuarioCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 290, 40));

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel4.setText("Contraseña:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));

        jContrasenaCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jPanel1.add(jContrasenaCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 290, 40));

        jRegistrarCliente.setBackground(new java.awt.Color(255, 153, 0));
        jRegistrarCliente.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jRegistrarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/organization.png"))); // NOI18N
        jRegistrarCliente.setText("Registrar ");
        jRegistrarCliente.setBorder(null);
        jRegistrarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jRegistrarCliente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jRegistrarCliente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jRegistrarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRegistrarClienteActionPerformed(evt);
            }
        });
        jPanel1.add(jRegistrarCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 430, 90, 50));

        jBRegresar.setBackground(new java.awt.Color(255, 153, 0));
        jBRegresar.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jBRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/return.png"))); // NOI18N
        jBRegresar.setText("Regresar");
        jBRegresar.setBorder(null);
        jBRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBRegresar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBRegresar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(jBRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 430, 100, -1));

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Registro 1.png"))); // NOI18N
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Empleado.png"))); // NOI18N
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 120));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 40, 350, 490));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Register.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRegistrarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRegistrarClienteActionPerformed
        String nombreCliente = jNombreCliente.getText(). trim();
        String cedulaCliente = jCedulaCliente.getText().trim();
        String usuarioCliente=jUsuarioCliente.getText().trim();
        String contrasenaCliente = jContrasenaCliente.getText().trim();
        
    if (nombreCliente.isEmpty()||cedulaCliente.isEmpty()||usuarioCliente.isEmpty()||contrasenaCliente.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Llenar Nombre");
    return;
     }
        
    if (cedulaCliente.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Llenar Cedula");
    return;
    }
    
    if (contrasenaCliente.isEmpty()){
        JOptionPane.showMessageDialog(this, "No sea cojudo hpta");
        return ;
    }

    if (usuarioCliente.isEmpty()){
        JOptionPane.showMessageDialog(this, "No sea cojudo hpta");
        return ;
    }
    
    try {
        Empleado empleado=new Empleado(nombreCliente, cedulaCliente, usuarioCliente, contrasenaCliente);
        gestionEmpleado.agregarEmpleado(empleado);
        gestionEmpleado.guardarEmpleadoEnArchivo(empleado);
        JOptionPane.showMessageDialog(this, "Cuenta creada con exito");
        Login log=new Login();
        log.setVisible(rootPaneCheckingEnabled);
        this.dispose();
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "No se pudo crear la cuenta", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}
        
    }//GEN-LAST:event_jRegistrarClienteActionPerformed

    private void jBRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBRegresarActionPerformed
        Login regreso=new Login();
        regreso.setVisible(rootPaneCheckingEnabled);
        this.dispose();        
    }//GEN-LAST:event_jBRegresarActionPerformed

  
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new JFRegistrarEmpleado().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBRegresar;
    private javax.swing.JTextField jCedulaCliente;
    private javax.swing.JTextField jContrasenaCliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField jNombreCliente;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jRegistrarCliente;
    private javax.swing.JTextField jUsuarioCliente;
    // End of variables declaration//GEN-END:variables
class FondoPanel extends javax.swing.JPanel {
    private Image imagen;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        imagen = new ImageIcon(getClass().getResource("/imagenes/Fondo2.png")).getImage(); // Reemplaza con tu ruta
        g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
    }
}
}
