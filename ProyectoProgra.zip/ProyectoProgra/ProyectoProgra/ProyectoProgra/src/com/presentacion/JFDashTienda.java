package com.presentacion;

import com.entidad.Cliente;
import com.negocio.GestionClientes;
import com.negocio.GestionTienda;
import com.negocio.SesionActual;

import java.awt.Color;
import javax.swing.table.DefaultTableModel;

/*
  Clase que representa la ventana principal para la tienda.
  Muestra el saldo del cliente logueado y el inventario de productos.
 * 
 * Se enfoca en la presentación y delega la lógica a GestionClientes y GestionTienda.
 */
public class JFDashTienda extends javax.swing.JFrame {

    // Instancias para gestionar clientes y productos
    private GestionClientes gestionClientes = new GestionClientes();
    private GestionTienda gestionTienda = new GestionTienda();

    // Modelo de tabla para mostrar productos
    private DefaultTableModel tablaProductos = new DefaultTableModel();

    // Logger para registro de eventos o errores
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JFDashTienda.class.getName());

    // Colores para la interfaz (ejemplo para botones o elementos)
    private Color DefaultColor, ClickedColor;

    /*
     * Constructor que inicializa los componentes y carga datos.
     */
    public JFDashTienda() {
        initComponents();

        // Obtener cliente logueado desde sesión actual
        Cliente cliente = SesionActual.clienteLogeado;

        // Si hay cliente logueado, mostrar su saldo en el área correspondiente
        if (cliente != null) {
            jTASaldo.setText(gestionClientes.mostrarSaldo(cliente));
        }

        // Cargar productos desde archivo para mostrar inventario actualizado
        gestionTienda.cargarProductosDesdeArchivo();

        // Definir columnas para la tabla de productos
        String[] ids = {"Nombre", "ID", "Precio", "Stock"};
        tablaProductos.setColumnIdentifiers(ids);

        // Actualizar la tabla para mostrar productos
        actualizarTabla();
    }

    /*
     * Actualiza el contenido de la tabla con los productos actuales.
     * Limpia las filas anteriores y agrega una fila por cada producto.
     */
    private void actualizarTabla() {
        tablaProductos.setRowCount(0); // Limpiar filas anteriores

        for (var producto : gestionTienda.getListaProducto()) {
            Object[] fila = {
                producto.getNombreProducto(),
                producto.getIdProducto(),
                producto.getPrecio(),
                producto.getStock()
            };
            tablaProductos.addRow(fila);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jBMenu = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTASaldo = new javax.swing.JTextArea();
        jLEstado = new javax.swing.JLabel();
        jDesktopPane2 = new javax.swing.JDesktopPane();
        jPanel4 = new javax.swing.JPanel();
        jBCompras = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bienvenido Empleado");

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen2_resized.png"))); // NOI18N
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        jBMenu.setBackground(new java.awt.Color(0, 153, 153));
        jBMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/logout.png"))); // NOI18N
        jBMenu.setBorder(null);
        jBMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBMenuActionPerformed(evt);
            }
        });
        jPanel2.add(jBMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 10, 110, 110));

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));

        jLabel1.setBackground(new java.awt.Color(0, 153, 153));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/wallet.png"))); // NOI18N

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("Saldo");

        jScrollPane1.setBorder(null);
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jTASaldo.setEditable(false);
        jTASaldo.setColumns(20);
        jTASaldo.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N
        jTASaldo.setRows(5);
        jTASaldo.setBorder(null);
        jScrollPane1.setViewportView(jTASaldo);
        jTASaldo.getAccessibleContext().setAccessibleParent(null);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel7)
                        .addContainerGap(56, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(14, 14, 14))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))))
        );

        jScrollPane1.getAccessibleContext().setAccessibleParent(null);

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 20, 200, -1));

        jLEstado.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 36)); // NOI18N
        jLEstado.setText("Inicio");
        jPanel2.add(jLEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 40, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, -1));

        jDesktopPane2.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jDesktopPane2Layout = new javax.swing.GroupLayout(jDesktopPane2);
        jDesktopPane2.setLayout(jDesktopPane2Layout);
        jDesktopPane2Layout.setHorizontalGroup(
            jDesktopPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 760, Short.MAX_VALUE)
        );
        jDesktopPane2Layout.setVerticalGroup(
            jDesktopPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 480, Short.MAX_VALUE)
        );

        jPanel1.add(jDesktopPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 144, 760, 480));

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jBCompras.setBackground(new java.awt.Color(0, 153, 153));
        jBCompras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Compra.png"))); // NOI18N
        jBCompras.setBorder(null);
        jBCompras.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Compra.png"))); // NOI18N
        jBCompras.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Compra 1.png"))); // NOI18N
        jBCompras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jBComprasMousePressed(evt);
            }
        });
        jBCompras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBComprasActionPerformed(evt);
            }
        });
        jPanel4.add(jBCompras, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 260, 200));

        jButton1.setBackground(new java.awt.Color(0, 153, 153));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Pago.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Pago.png"))); // NOI18N
        jButton1.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Pago 1.png"))); // NOI18N
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 250, 170));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 290, 480));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jBMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBMenuActionPerformed
        Login login=new Login();
        login.setVisible(rootPaneCheckingEnabled);
        this.dispose();
    }//GEN-LAST:event_jBMenuActionPerformed

    private void jBComprasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBComprasActionPerformed
        MenuTienda menuT=new MenuTienda();
        jDesktopPane2.removeAll();
        jDesktopPane2.add(menuT).setVisible(true);  
        jLEstado.setText("Tienda");
    }//GEN-LAST:event_jBComprasActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        MenuReciente menuR=new MenuReciente();
        jDesktopPane2.removeAll();
        jDesktopPane2.add(menuR).setVisible(true);  
        jLEstado.setText("Pedidos");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jBComprasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jBComprasMousePressed

    }//GEN-LAST:event_jBComprasMousePressed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new JFDashTienda().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBCompras;
    private javax.swing.JButton jBMenu;
    private javax.swing.JButton jButton1;
    private javax.swing.JDesktopPane jDesktopPane2;
    private javax.swing.JLabel jLEstado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTASaldo;
    // End of variables declaration//GEN-END:variables
}
