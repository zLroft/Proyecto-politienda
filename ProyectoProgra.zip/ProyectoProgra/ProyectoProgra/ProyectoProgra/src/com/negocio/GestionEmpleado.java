package com.negocio;

import com.entidad.Empleado;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/*
  Clase que gestiona las operaciones relacionadas con los empleados.
  Responsable de almacenar, autenticar, cargar y guardar empleados.  
 */
public class GestionEmpleado {

    // Lista interna de empleados en memoria
    private List<Empleado> listaEmpleados;

    // Constructor que inicializa la lista
    public GestionEmpleado() {
        this.listaEmpleados = new ArrayList<>();
    }

    /*
      Método para autenticar empleado dado un usuario y contraseña.
      usuario Nombre de usuario del empleado
      contrasena Contraseña del empleado
      Empleado autenticado o null si no se encuentra coincidencia
     */
    public Empleado autenticar(String usuario, String contrasena) {
        for (Empleado e : listaEmpleados) {
            if (e.getUsuarioEmpleado().equals(usuario) && e.getContraseniaEmpleado().equals(contrasena)) {
                return e;
            }
        }
        return null;
    }

    /*
      Agrega un nuevo empleado a la lista en memoria.
      empleado Empleado a agregar
     */
    public void agregarEmpleado(Empleado empleado) {
        listaEmpleados.add(empleado);
    }

    /*
     Devuelve la lista completa de empleados en memoria.
     return Lista de empleados
     */
    public List<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }

    /*
      Muestra la información básica de un empleado en formato legible.
       e Empleado a mostrar
       String con datos del empleado
     */
    public String mostrarEmpleado(Empleado e) {
        return "Nombre: " + e.getNombreEmpleado() + "\n" +
               "Usuario: " + e.getUsuarioEmpleado() + "\n" +
               "Cédula: " + e.getCedulaEmpleado() + "\n";
    }

    /*
      Guarda un empleado nuevo en archivo "Empleados.csv" .
     Formato CSV: nombreEmpleado, cedulaEmpleado, usuarioEmpleado, contraseniaEmpleado
      empleado Empleado a guardar
     */
    public void guardarEmpleadoEnArchivo(Empleado empleado) {
        try (FileWriter fw = new FileWriter("Empleados.csv", true);
             PrintWriter pw = new PrintWriter(fw)) {

            String linea = String.join(",",
                    empleado.getNombreEmpleado(),
                    empleado.getCedulaEmpleado(),
                    empleado.getUsuarioEmpleado(),
                    empleado.getContraseniaEmpleado());

            pw.println(linea);

        } catch (IOException e) {
            System.out.println("Error al guardar empleado: " + e.getMessage());
        }
    }

    /*
      Carga empleados desde el archivo "Empleados.csv" y los almacena en memoria.
      Limpia la lista antes de cargar.
      Corrige el orden y número de campos para coincidir con el guardado.
     */
    public void cargarEmpleadosDesdeArchivo() {
        listaEmpleados.clear(); // Limpiar lista antes de cargar

        try (BufferedReader br = new BufferedReader(new FileReader("Empleados.csv"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");

                if (partes.length >= 4) {
                    // Orden según guardarEmpleadoEnArchivo:
                    // nombreEmpleado, cedulaEmpleado, usuarioEmpleado, contraseniaEmpleado
                    String nombre = partes[0].trim();
                    String cedula = partes[1].trim();
                    String usuario = partes[2].trim();
                    String contrasenia = partes[3].trim();

                    Empleado empleado = new Empleado(nombre, cedula, usuario, contrasenia);
                    listaEmpleados.add(empleado);
                } else {
                    System.err.println("Línea inválida (faltan campos): " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar empleados: " + e.getMessage());
        }
    }

}

