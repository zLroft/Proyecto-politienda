package com.negocio;

import com.entidad.Cliente;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/*
  Clase que gestiona las operaciones relacionadas con los clientes.
  Responsable de almacenar, autenticar, cargar y guardar clientes. 
 */
public class GestionClientes {

    // Lista interna de clientes en memoria
    private List<Cliente> listaClientes;

    // Constructor inicializa la lista
    public GestionClientes() {
        this.listaClientes = new ArrayList<>();
    }

    // Getter para obtener la lista completa de clientes
    public List<Cliente> getListaClientes() {
        return listaClientes;
    }

    // Setter para reemplazar la lista completa
    public void setListaClientes(List<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }

    /*
      Autentica un cliente buscando usuario y contraseña.
      usuario Usuario a autenticar
      contrasena Contraseña correspondiente
      Cliente autenticado o null si no existe
     */
    public Cliente autenticar(String usuario, String contrasena) {
        for (Cliente c : listaClientes) {
            if (c.getUsuarioCliente().equals(usuario) && c.getContraseniaCliente().equals(contrasena)) {
                return c;
            }
        }
        return null;
    }

    /*
      Agrega un cliente nuevo a la lista en memoria.
      cliente Cliente a agregar
     */
    public void agregarCliente(Cliente cliente) {
        listaClientes.add(cliente);
    }

    /*
      Retorna una representación en String del primer cliente de la lista. 
      String del cliente o null si no hay clientes
     */
    public String mostrarCliente() {
        if (!listaClientes.isEmpty()) {
            return listaClientes.get(0).toString();
        }
        return null;
    }

    /*
      Método para simular el pago de un pedido.
      Verifica si algún cliente tiene saldo suficiente para pagar.
      Si es así, guarda todos los clientes actualizados.
      Si no, muestra un mensaje de saldo insuficiente.
     */
    public void pagoPedido(double precio) {
        for (Cliente c : listaClientes) {
            if (precio < c.getSaldo()) {
                // Aquí debería descontar el saldo, no solo guardar
                guardarTodosLosClientes();
                return; // Sale si encontró cliente con saldo suficiente
            }
        }
        JOptionPane.showMessageDialog(null, "Saldo insuficiente");
    }

    /*
      Muestra el saldo de un cliente formateado con símbolo $
      c Cliente del cual mostrar saldo
      Saldo en String con símbolo $
     */
    public String mostrarSaldo(Cliente c) {
        return String.format("%.2f$", c.getSaldo());
    }

    /*
      Guarda un cliente nuevo en el archivo "clientes.csv"
      Cada cliente se guarda en formato CSV: nombre,cedula,usuario,contraseña,saldo
      
      cliente Cliente a guardar
     */
    public void guardarClienteEnArchivo(Cliente cliente) {
        try (FileWriter fw = new FileWriter("clientes.csv", true);
             PrintWriter pw = new PrintWriter(fw)) {

            String linea = String.join(",",
                    cliente.getNombreCliente(),
                    cliente.getCedulaCliente(),
                    cliente.getUsuarioCliente(),
                    cliente.getContraseniaCliente(),
                    String.valueOf(cliente.getSaldo()));
            pw.println(linea);

        } catch (IOException e) {
            System.out.println("Error al guardar cliente: " + e.getMessage());
        }
    }

    /**
     * Carga todos los clientes desde el archivo "clientes.csv"
     * Limpia la lista en memoria antes de cargar
     */
    public void cargarClientesDesdeArchivo() {
        listaClientes.clear(); // Limpiar lista antes de cargar

        try (BufferedReader br = new BufferedReader(new FileReader("clientes.csv"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");

                if (partes.length >= 5) {
                    // El orden según guardarClienteEnArchivo es:
                    // nombreCliente, cedulaCliente, usuarioCliente, contraseniaCliente, saldo
                    String nombre = partes[0].trim();
                    String cedula = partes[1].trim();
                    String usuario = partes[2].trim();
                    String contrasenia = partes[3].trim();
                    double saldo = Double.parseDouble(partes[4].trim());

                    Cliente cliente = new Cliente(nombre, cedula, usuario, contrasenia, saldo);
                    listaClientes.add(cliente);
                } else {
                    System.err.println("Línea inválida (faltan campos): " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar clientes: " + e.getMessage());
        }
    }

    /*
     Guarda toda la lista de clientes en el archivo "clientes.csv"
     Sobrescribe el archivo para reflejar cambios actuales
     */
    public void guardarTodosLosClientes() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("clientes.csv"))) {
            for (Cliente c : listaClientes) {
                String linea = String.join(",",
                        c.getNombreCliente(),
                        c.getCedulaCliente(),
                        c.getUsuarioCliente(),
                        c.getContraseniaCliente(),
                        String.valueOf(c.getSaldo()));
                bw.write(linea);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al guardar clientes: " + e.getMessage());
        }
    }

}
