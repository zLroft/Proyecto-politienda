package com.negocio;

import com.entidad.Venta;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

/*
  Clase que gestiona la lógica relacionada con los productos (ventas).
  Responsable de almacenar, modificar, eliminar, cargar y guardar productos.
 */
public class GestionTienda {

    // Lista interna que almacena los productos en memoria
    private List<Venta> listaProducto;

    // Constructor que inicializa la lista
    public GestionTienda() {
        this.listaProducto = new ArrayList<>();
    }

    // Getter para la lista de productos
    public List<Venta> getListaProducto() {
        return listaProducto;
    }

    // Setter para la lista de productos
    public void setListaProducto(List<Venta> listaProducto) {
        this.listaProducto = listaProducto;
    }

    /*
      Agrega un nuevo producto a la lista.
      venta Producto a agregar
     */
    public void agregarProducto(Venta venta) {
        listaProducto.add(venta);
    }

    /*
      Devuelve un String con la representación de todos los productos.
       String con la info concatenada de todos los productos
     */
    public String mostrarProductos() {
        StringBuilder salida = new StringBuilder();
        for (Venta v : listaProducto) {
            salida.append(v.toString()).append("\n");
        }
        return salida.toString();
    }

    /*
      Verifica que no existan productos con mismo ID o nombre.
      Si encuentra coincidencia muestra mensaje de alerta.
      venta Producto a validar
       true si no hay conflictos, false si ya existe
     */
    public boolean verificarExistencia(Venta venta) {
        for (Venta v : listaProducto) {
            if (v.getIdProducto().equals(venta.getIdProducto())) {
                JOptionPane.showMessageDialog(null, "El ID ya existe");
                return false;
            }
            if (v.getNombreProducto().equalsIgnoreCase(venta.getNombreProducto())) {
                JOptionPane.showMessageDialog(null, "El nombre ya existe");
                return false;
            }
        }
        return true;
    }

    /*
      Elimina un producto de la lista y guarda los cambios en archivo.
      venta Producto a eliminar
     */
    public void eliminarProducto(Venta venta) {
        listaProducto.remove(venta);
        guardarTodosLosProductos();
    }

    /*
      Reduce el stock de un producto identificado por id en la cantidad especificada.
      Guarda los cambios en archivo.
       id ID del producto
       cantidad Cantidad a reducir
       true si producto existe y stock fue reducido, false si no existe
     */
    public boolean reducir(String id, int cantidad) {
        for (Venta v : listaProducto) {
            if (v.getIdProducto().equals(id)) {
                v.reducirStock(cantidad);
                guardarTodosLosProductos();
                return true;
            }
        }
        return false;
    }

    /*
      Aumenta el stock de un producto identificado por id en la cantidad especificada.
       id ID del producto
       cantidad Cantidad a agregar
       true si producto existe y stock fue incrementado, false si no existe
     */
    public boolean agregar(String id, int cantidad) {
        for (Venta v : listaProducto) {
            if (v.getIdProducto().equals(id)) {
                v.agregarStock(cantidad);
                return true;
            }
        }
        return false;
    }

    /*
      Guarda un producto en archivo "Productos.csv".
      Formato CSV: nombreProducto, idProducto, precio, stock
       venta Producto a guardar
     */
    public void guardarProductoEnArchivo(Venta venta) {
        try (FileWriter fw = new FileWriter("Productos.csv", true);
             PrintWriter pw = new PrintWriter(fw)) {

            String linea = String.join(",",
                    venta.getNombreProducto(),
                    venta.getIdProducto(),
                    String.valueOf(venta.getPrecio()),
                    String.valueOf(venta.getStock()));

            pw.println(linea);

        } catch (IOException e) {
            System.out.println("Error al guardar producto: " + e.getMessage());
        }
    }

    /*
      Guarda todos los productos actuales en el archivo "Productos.csv".
      Sobrescribe el archivo para reflejar el estado actual.
     */
    public void guardarTodosLosProductos() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("Productos.csv"))) {
            for (Venta v : listaProducto) {
                String linea = String.join(",",
                        v.getNombreProducto(),
                        v.getIdProducto(),
                        String.valueOf(v.getPrecio()),
                        String.valueOf(v.getStock()));
                bw.write(linea);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al guardar productos: " + e.getMessage());
        }
    }

    /*
      Carga todos los productos desde el archivo "Productos.csv".
      Limpia la lista antes de cargar.
     */
    public void cargarProductosDesdeArchivo() {
        listaProducto.clear(); // Limpiar antes de cargar

        try (BufferedReader br = new BufferedReader(new FileReader("Productos.csv"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");

                if (partes.length >= 4) {
                    String nombreP = partes[0].trim();
                    String idP = partes[1].trim();
                    double precio = Double.parseDouble(partes[2].trim());
                    int stock = Integer.parseInt(partes[3].trim());

                    Venta venta = new Venta(nombreP, idP, precio, stock);
                    listaProducto.add(venta);
                } else {
                    System.err.println("Línea inválida (faltan campos): " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar productos: " + e.getMessage());
        }
    }
}

    
