
package com.negocio;

import com.entidad.Cliente;
import com.entidad.Empleado;

public class SesionActual {
    
    public static Empleado empleadoLogueado;
    public static Cliente clienteLogeado;

}
