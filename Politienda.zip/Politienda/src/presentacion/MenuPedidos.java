
package presentacion;

import entidad.Cliente;
import entidad.Pedido;
import entidad.Venta;
import java.util.ArrayList;
import java.util.List;
import negocio.GestionProductos;
import negocio.Sesion;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import negocio.GestionClientes;
import negocio.GestionPedidos;

public class MenuPedidos extends javax.swing.JInternalFrame {
        DefaultTableModel modelo = new DefaultTableModel();
        private GestionPedidos gestionPedido=new GestionPedidos();
        private GestionProductos gestiontienda=new GestionProductos();
        private GestionClientes gestionCliente=new GestionClientes();
        private Cliente actual=Sesion.clienteLogeado;
    public MenuPedidos() {
        initComponents();
        this.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        BasicInternalFrameUI ui=(BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
        String[] ids = {"ID Pedido", "Fecha", "Total", "Cantidad"};
        modelo.setColumnIdentifiers(ids);
        gestionPedido.cargarPedidos();
        cargarPedidosDelCliente(actual);
        gestionPedido.cargarPedidos();
    }
public void cargarPedidosDelCliente(Cliente cliente) {
    List<Pedido> pedidos = gestionPedido.getListaPedidos();
    if (pedidos == null) pedidos = new ArrayList<>();

    for (Pedido pedido : pedidos) {
        // Filtrar por cédula del cliente
        if (!pedido.getCedulaCliente().equals(cliente.getCedulaCliente())) {
            continue;
        }

        String resumen = pedido.getProductos().stream()
            .map(p -> p.getNombreProducto() + "*" + p.getStock())
            .reduce("", (a, b) -> a + ", " + b);
        
        modelo.addRow(new Object[]{
            pedido.getCodigoPedido(),
            pedido.getFecha(),
            pedido.getTotal(),
            resumen.length() > 2 ? resumen.substring(2) : resumen
        });
    }

    jTPedidos.setModel(modelo);
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTPedidos = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jBPagar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jTFTpagar = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTFIDPedido = new javax.swing.JTextField();
        jBCancelar = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();

        jPanel1.setPreferredSize(new java.awt.Dimension(760, 480));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTPedidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Producto", "ID", "Precio unitario", "cantidad", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTPedidos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTPedidosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTPedidos);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, 530));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Pago", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Segoe UI", 0, 24))); // NOI18N

        jBPagar.setBackground(new java.awt.Color(204, 204, 204));
        jBPagar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jBPagar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/credit-card.png"))); // NOI18N
        jBPagar.setText("Pagar");
        jBPagar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jBPagar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBPagar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBPagar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBPagarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Total a pagar:");

        jTFTpagar.setEditable(false);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("ID Pedido:");

        jTFIDPedido.setEditable(false);

        jBCancelar.setBackground(new java.awt.Color(204, 204, 204));
        jBCancelar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jBCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/close.png"))); // NOI18N
        jBCancelar.setText("Cancelar pedido");
        jBCancelar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jBCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBCancelar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBCancelar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTFTpagar, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTFIDPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1)))
                        .addGap(0, 20, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jBCancelar)
                    .addComponent(jBPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jBPagar)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFTpagar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jBCancelar)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(26, 26, 26)
                        .addComponent(jTFIDPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)))
                .addGap(0, 66, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 151, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 0, 430, 530));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 900, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 534, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBPagarActionPerformed
            int filaSeleccionada = jTPedidos.getSelectedRow();

    if (filaSeleccionada < 0) {
        JOptionPane.showMessageDialog(this, "Selecciona un pedido para pagar.");
        return;
    }

    String idPedido = jTPedidos.getValueAt(filaSeleccionada, 0).toString(); // ID pedido
    Cliente cliente = Sesion.clienteLogeado;

    Pedido pedidoAPagar = null;
    for (Pedido p : gestionPedido.getListaPedidos()) {
        if (p.getCodigoPedido().equals(idPedido)) {
            pedidoAPagar = p;
            break;
        }
    }

    if (pedidoAPagar == null) {
        JOptionPane.showMessageDialog(this, "No se encontró el pedido.");
        return;
    }

    double total = pedidoAPagar.getTotal();

    if (cliente.getSaldo() < total) {
        JOptionPane.showMessageDialog(this, "Saldo insuficiente para pagar el pedido.");
        return;
    }

    // Confirmar pago
    int confirmar = JOptionPane.showConfirmDialog(this, "¿Deseas pagar este pedido por $" + total + "?", "Confirmar Pago", JOptionPane.YES_NO_OPTION);
    if (confirmar != JOptionPane.YES_OPTION) return;

    // Realizar pago
    cliente.setSaldo(cliente.getSaldo() - total);

    gestionCliente.actualizarCliente(cliente); // Asegúrate de tener este método

    // Eliminar pedido
    gestionPedido.cancelarPedido(pedidoAPagar);

    JOptionPane.showMessageDialog(this, "Pago realizado correctamente. Nuevo saldo: $" + cliente.getSaldo());   

    }//GEN-LAST:event_jBPagarActionPerformed

    private void jBCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCancelarActionPerformed
    int filaSeleccionada = jTPedidos.getSelectedRow();

    if (filaSeleccionada >= 0) {
        int confirm = JOptionPane.showConfirmDialog(this, "¿Deseas cancelar este pedido?", "Confirmar cancelación", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Obtener el ID del pedido desde la tabla (columna 0, usualmente)
            String idPedido = jTPedidos.getValueAt(filaSeleccionada, 0).toString();

            // Buscar el pedido en la lista de gestión
            Pedido pedidoCancelar = null;
            for (Pedido p : gestionPedido.getListaPedidos()) {
                if (p.getCodigoPedido().equals(idPedido)) {
                    pedidoCancelar = p;
                    break;
                }
            }

            if (pedidoCancelar != null) {
                // Cancelar pedido
                gestionPedido.guardarTodosLosPedidos(pedidoCancelar);

                // Quitar fila de la tabla
                DefaultTableModel modeloTabla = (DefaultTableModel) jTPedidos.getModel();
                modeloTabla.removeRow(filaSeleccionada);

                JOptionPane.showMessageDialog(this, "Pedido cancelado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el pedido.");
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Selecciona un pedido para cancelar.");
    }
  
    }//GEN-LAST:event_jBCancelarActionPerformed

    private void jTPedidosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTPedidosMouseClicked
    int filaSeleccionada = jTPedidos.getSelectedRow();

    if (filaSeleccionada >= 0) {
        // Obtener el total desde la tabla (columna 2)
        String total = jTPedidos.getValueAt(filaSeleccionada, 2).toString();
        String nroPedido=jTPedidos.getValueAt(filaSeleccionada,0).toString();

        // Mostrar en el JTextField
        jTFTpagar.setText(total);
        jTFIDPedido.setText(nroPedido);
    }
    }//GEN-LAST:event_jTPedidosMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBCancelar;
    private javax.swing.JButton jBPagar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTFIDPedido;
    private javax.swing.JTextField jTFTpagar;
    private javax.swing.JTable jTPedidos;
    // End of variables declaration//GEN-END:variables
}
