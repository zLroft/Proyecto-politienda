
package presentacion;

import entidad.Cliente;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import negocio.GestionClientes;

public class JFRCliente extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JFRCliente.class.getName());
    private FondoPanel fondo = new FondoPanel();
    private GestionClientes gestionClientes=new GestionClientes();

    public JFRCliente() {
        this.setContentPane(fondo);
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jNombreCliente = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jCedulaCliente = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jUsuarioCliente = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jContrasenaCliente = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        jFTSaldo = new javax.swing.JTextField();
        jRegistrarCliente = new javax.swing.JButton();
        jBRegresar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 600));
        setPreferredSize(new java.awt.Dimension(1000, 601));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setForeground(new java.awt.Color(255, 0, 51));
        jPanel1.setToolTipText("");
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setPreferredSize(new java.awt.Dimension(350, 490));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel1.setText("Nombre:");

        jNombreCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jNombreCliente.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel2.setText("Cedula:");

        jCedulaCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jCedulaCliente.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jCedulaCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCedulaClienteActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel3.setText("Usuario:");

        jUsuarioCliente.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jUsuarioCliente.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel4.setText("Contraseña:");

        jContrasenaCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jContrasenaClienteActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel6.setText("Saldo Inicial:");

        jRegistrarCliente.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jRegistrarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/log-in.png"))); // NOI18N
        jRegistrarCliente.setText("Registrar ");
        jRegistrarCliente.setBorder(null);
        jRegistrarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jRegistrarCliente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jRegistrarCliente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jRegistrarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRegistrarClienteActionPerformed(evt);
            }
        });

        jBRegresar.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jBRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/previous.png"))); // NOI18N
        jBRegresar.setText("Regresar");
        jBRegresar.setBorder(null);
        jBRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBRegresar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBRegresar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jContrasenaCliente)
                    .addComponent(jUsuarioCliente)
                    .addComponent(jCedulaCliente)
                    .addComponent(jNombreCliente)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6)
                    .addComponent(jFTSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jRegistrarCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jBRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCedulaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jUsuarioCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jContrasenaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jFTSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jBRegresar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(105, 105, 105))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jRegistrarCliente)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, 320, 550));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen2_resized.png"))); // NOI18N
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, -1, -1));

        jLabel8.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        jLabel8.setText("<html>Descubre mas sobre nosotros<br>     y sobre nuestros productos      ,<br>   registrate para averiguarlo ");
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 170, 190));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/excellence.png"))); // NOI18N
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, 70, 120));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 500, 550));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/RegisterH.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 90, 470, 380));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRegistrarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRegistrarClienteActionPerformed
        String nombreCliente = jNombreCliente.getText(). trim();
        String cedulaCliente = jCedulaCliente.getText().trim();
        String usuarioCliente=jUsuarioCliente.getText().trim();
        String contrasenaCliente = jContrasenaCliente.getText();
        String saldoInicial=jFTSaldo.getText();

        if (nombreCliente.isEmpty()||cedulaCliente.isEmpty()||usuarioCliente.isEmpty()||contrasenaCliente.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Llenar los campos");
            return;
        }

        double dinero;

        try {
            dinero = Double.parseDouble(saldoInicial);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser valores numéricos válidos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (dinero <= 0 ) {
            JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser mayores que 0", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Cliente cliente=new Cliente(nombreCliente, cedulaCliente, usuarioCliente, contrasenaCliente,dinero);
            gestionClientes.guardarClientes(cliente);
            JOptionPane.showMessageDialog(this, "Cuenta creada con exito");
            Login log=new Login();
            log.setVisible(rootPaneCheckingEnabled);
            this.dispose();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "No se pudo crear la cuenta", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

    }//GEN-LAST:event_jRegistrarClienteActionPerformed

    private void jBRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBRegresarActionPerformed
        Login regreso=new Login();
        regreso.setVisible(rootPaneCheckingEnabled);
        this.dispose();
    }//GEN-LAST:event_jBRegresarActionPerformed

    private void jContrasenaClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jContrasenaClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jContrasenaClienteActionPerformed

    private void jCedulaClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCedulaClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCedulaClienteActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new JFRCliente().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBRegresar;
    private javax.swing.JTextField jCedulaCliente;
    private javax.swing.JPasswordField jContrasenaCliente;
    private javax.swing.JTextField jFTSaldo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jNombreCliente;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jRegistrarCliente;
    private javax.swing.JTextField jUsuarioCliente;
    // End of variables declaration//GEN-END:variables
class FondoPanel extends javax.swing.JPanel {
    private Image imagen;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        imagen = new ImageIcon(getClass().getResource("/imagenes/Fondo2.png")).getImage(); // Reemplaza con tu ruta
        g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
    }
}
}
