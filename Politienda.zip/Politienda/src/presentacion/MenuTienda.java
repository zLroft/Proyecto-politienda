package presentacion;

import entidad.Cliente;
import entidad.Pedido;
import entidad.Producto;
import entidad.Venta;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import negocio.GestionProductos;
import negocio.Sesion;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import negocio.GestionClientes;
import negocio.GestionPedidos;

/*
 * Clase que representa la interfaz interna para gestionar la tienda y mostrar productos disponibles para venta.
 * Se encarga exclusivamente de la presentación y delega la lógica a GestionTienda.
 */
public class MenuTienda extends javax.swing.JInternalFrame {

    private GestionClientes gestionCliente=new GestionClientes();
    
    private Cliente actual = Sesion.clienteLogeado;
    
    private GestionPedidos gestionPedido=new GestionPedidos();
    
    // Instancia que gestiona la lógica y datos de la tienda
    private GestionProductos gestionTienda = new GestionProductos();

    // Modelo para la tabla que mostrará los productos en la UI
    private DefaultTableModel tablaProductos = new DefaultTableModel();
    
    TableRowSorter<DefaultTableModel> rowSorter = new TableRowSorter<>(tablaProductos);
    

    /*
     * Constructor que inicializa los componentes gráficos y carga los productos desde archivo.
     */
    public MenuTienda() {
        initComponents();

        // Eliminar bordes y panel superior para personalización del JInternalFrame
        this.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);

        // Definir las columnas que tendrá la tabla de productos
        String[] columnas = {"Nombre", "ID", "Precio", "Stock"};
        tablaProductos.setColumnIdentifiers(columnas);

        // Asignar el modelo al JTable en la interfaz
        jTVenta.setModel(tablaProductos);
        jTVenta.setRowSorter(rowSorter);

        // Cargar productos almacenados para mostrar en la tabla
        gestionTienda.cargarProductos();

        // Actualizar la tabla con los datos cargados
        actualizarTabla();
        
        jTFBuscar.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) {
        filtrar();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        filtrar();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        filtrar();
    }

    private void filtrar() {
        String texto = jTFBuscar.getText();
        if (texto.trim().length() == 0) {
            rowSorter.setRowFilter(null);
        } else {
            // Filtrar solo por la primera columna (índice 0: "Nombre")
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto, 0));
        }
    }
});

    }

    /*
     * Método para actualizar la tabla con los productos actuales.
     * Limpia las filas existentes y agrega una fila por cada producto.
     */
    private void actualizarTabla() {
        tablaProductos.setRowCount(0); // Limpiar filas existentes

        // Recorrer productos y agregarlos como filas en la tabla
        for (var producto : gestionTienda.getListaProducto()) {
            Object[] fila = {
                producto.getNombreProducto(),
                producto.getIdProducto(),
                producto.getPrecio(),
                producto.getStock()
            };
            
            
jTFCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
    public void keyReleased(java.awt.event.KeyEvent evt) {
        actualizarTotal();
    }
});
            tablaProductos.addRow(fila);
        }
    }
    
    private void actualizarTotal() {
    int filaSeleccionada = jTVenta.getSelectedRow();
    if (filaSeleccionada < 0) return;

    String cantidadTexto = jTFCantidad.getText().trim();
    if (cantidadTexto.isEmpty()) {
        jTATotal.setText("Ingrese una cantidad.");
        return;
    }

    try {
        int cantidad = Integer.parseInt(cantidadTexto);
        double precio = Double.parseDouble(tablaProductos.getValueAt(filaSeleccionada, 2).toString());
        double total = cantidad * precio;

        String nombre = tablaProductos.getValueAt(filaSeleccionada, 0).toString();

        jTATotal.setText(total+"$");
    } catch (NumberFormatException e) {
        jTATotal.setText("Cantidad inválida.");
    }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTVenta = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTFCantidad = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTATotal = new javax.swing.JTextArea();
        jBAgregarPedido = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTFBuscar = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setMinimumSize(new java.awt.Dimension(910, 570));
        setPreferredSize(new java.awt.Dimension(910, 570));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTVenta.setBackground(new java.awt.Color(0, 0, 0));
        jTVenta.setForeground(new java.awt.Color(255, 255, 255));
        jTVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Productos", "Id", "Precio", "En stock"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTVenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTVentaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTVenta);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 470, 490));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("Cantidad:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 50, 30));
        jPanel1.add(jTFCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 130, 30));

        jLabel3.setText("Total:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 30, 30));

        jScrollPane2.setBorder(null);
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jTATotal.setEditable(false);
        jTATotal.setBackground(new java.awt.Color(255, 255, 255));
        jTATotal.setColumns(20);
        jTATotal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTATotal.setRows(5);
        jTATotal.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jScrollPane2.setViewportView(jTATotal);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 190, 30));

        jBAgregarPedido.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jBAgregarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Pedido.png"))); // NOI18N
        jBAgregarPedido.setText("Agregar pedido");
        jBAgregarPedido.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jBAgregarPedido.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBAgregarPedido.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBAgregarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAgregarPedidoActionPerformed(evt);
            }
        });
        jPanel1.add(jBAgregarPedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 0, 440, 240));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/search (1).png"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 40, 40));

        jTFBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jTFBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFBuscarActionPerformed(evt);
            }
        });
        jPanel2.add(jTFBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 300, 40));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, 550));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Tienda.jpg"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 240, 440, 310));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTVentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTVentaMouseClicked
                                  
    int filaSeleccionada = jTVenta.getSelectedRow(); // Fila seleccionada

    if (filaSeleccionada >= 0) {
        jTFCantidad.setEnabled(true); // Activar el campo de cantidad
        jTFCantidad.setText("");      // Limpiar valor anterior
        jTFCantidad.requestFocus();   // Dar foco

        // Mostrar precio unitario y producto seleccionado (opcional)
        String nombre = tablaProductos.getValueAt(filaSeleccionada, 0).toString();
        String id = tablaProductos.getValueAt(filaSeleccionada, 1).toString();
        double precio = Double.parseDouble(tablaProductos.getValueAt(filaSeleccionada, 2).toString());

        // Mostrar en el área de texto
        
    }
    }//GEN-LAST:event_jTVentaMouseClicked

    private void jTFBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFBuscarActionPerformed

    private void jBAgregarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAgregarPedidoActionPerformed
    int filaSeleccionada = jTVenta.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Seleccione un producto.");
        return;
    }

    String cantidadTexto = jTFCantidad.getText().trim();
    if (cantidadTexto.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Ingrese una cantidad.");
        return;
    }

    int cantidad;
    try {
        cantidad = Integer.parseInt(cantidadTexto);
        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor que cero.");
            return;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Ingrese un número válido.");
        return;
    }

    // Obtener el producto real desde la listaProducto (coincide con el índice de la tabla)
    Venta productoSeleccionado = gestionTienda.getListaProducto().get(filaSeleccionada);

    // Crear producto para el pedido
    Producto productoPedido = new Producto(
        productoSeleccionado.getIdProducto(), 
        productoSeleccionado.getNombreProducto(), 
        productoSeleccionado.getPrecio(), 
        cantidad
    );
    
    String nombre = tablaProductos.getValueAt(filaSeleccionada, 0).toString();
    String id = tablaProductos.getValueAt(filaSeleccionada, 1).toString();
    double precio = Double.parseDouble(tablaProductos.getValueAt(filaSeleccionada, 2).toString());
    int stock = Integer.parseInt(tablaProductos.getValueAt(filaSeleccionada, 3).toString());


    double total = productoPedido.getPrecio() * cantidad;

    List<Producto> productosDelPedido = new ArrayList<>();
    productosDelPedido.add(productoPedido);

    String cedula = Sesion.clienteLogeado.getCedulaCliente();

    // ✅ Crear pedido con la cédula del cliente incluida
    Pedido pedido = new Pedido("Nro-" + System.currentTimeMillis(), productosDelPedido, total, new Date(), cedula);

    // Guardar el pedido
    gestionPedido.guardarPedidos(pedido);
    
    boolean exito = gestionTienda.reducir(id,cantidad);

    if (exito) {
        tablaProductos.setValueAt(stock - cantidad, filaSeleccionada, 3); // actualizar visual
    } else {
        JOptionPane.showMessageDialog(this, "Error al reducir stock.");
        return;
    }

    JOptionPane.showMessageDialog(this, "Pedido realizado y guardado correctamente.");

    // Limpiar campos
    jTFCantidad.setText("");
    jTFCantidad.setEnabled(false);
    jTVenta.clearSelection();
    }//GEN-LAST:event_jBAgregarPedidoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBAgregarPedido;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTATotal;
    private javax.swing.JTextField jTFBuscar;
    private javax.swing.JTextField jTFCantidad;
    private javax.swing.JTable jTVenta;
    // End of variables declaration//GEN-END:variables

}
