
package presentacion;

import entidad.Venta;
import negocio.GestionEmpleados;
import negocio.GestionProductos;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class MenuStock extends javax.swing.JInternalFrame {

    private GestionProductos gestionProductos=new GestionProductos();
    private GestionEmpleados gestionEmpleado=new GestionEmpleados();
    DefaultTableModel tablaProductos=new DefaultTableModel();
    TableRowSorter<DefaultTableModel> rowSorter = new TableRowSorter<>(tablaProductos);
    public MenuStock() {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        BasicInternalFrameUI ui=(BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
        String ids[]={"Nombre","ID","Precio","Stock"};
        tablaProductos.setColumnIdentifiers(ids);
        jTProductos.setModel(tablaProductos);
        jTProductos.setRowSorter(rowSorter);
        gestionProductos.cargarProductos();
        actualizarTabla();
        
            jTFBuscar.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) {
        filtrar();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        filtrar();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        filtrar();
    }

    private void filtrar() {
        String texto = jTFBuscar.getText();
        if (texto.trim().length() == 0) {
            rowSorter.setRowFilter(null);
        } else {
            // Filtrar solo por la primera columna (índice 0: "Nombre")
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto, 0));
        }
    }
}); 
    }
    
    private void actualizarTabla() {
    tablaProductos.setRowCount(0); 

    for (var producto : gestionProductos.getListaProducto()) {
        Object[] fila = {producto.getNombreProducto(), producto.getIdProducto(), producto.getPrecio(), producto.getStock()};
        tablaProductos.addRow(fila);
    }
}  

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTFNumeroID = new javax.swing.JTextField();
        jTFCantidads = new javax.swing.JTextField();
        jBEliminar = new javax.swing.JButton();
        jBAgregarStock = new javax.swing.JButton();
        jTFBuscar = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTProductos = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setMinimumSize(new java.awt.Dimension(930, 550));
        setPreferredSize(new java.awt.Dimension(930, 550));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos del producto", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18))); // NOI18N
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("ID:");
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("Cantidad:");
        jPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        jTFNumeroID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPanel4.add(jTFNumeroID, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 200, 30));

        jTFCantidads.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPanel4.add(jTFCantidads, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 200, 30));

        jBEliminar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jBEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/delete (1).png"))); // NOI18N
        jBEliminar.setText("Eliminar producto");
        jBEliminar.setBorder(null);
        jBEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBEliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBEliminar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBEliminarActionPerformed(evt);
            }
        });
        jPanel4.add(jBEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 410, -1, -1));

        jBAgregarStock.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jBAgregarStock.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/add (1).png"))); // NOI18N
        jBAgregarStock.setText("Agregar stock");
        jBAgregarStock.setBorder(null);
        jBAgregarStock.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBAgregarStock.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBAgregarStock.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBAgregarStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAgregarStockActionPerformed(evt);
            }
        });
        jPanel4.add(jBAgregarStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 410, 136, -1));

        jTFBuscar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTFBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFBuscarActionPerformed(evt);
            }
        });
        jPanel4.add(jTFBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 200, 30));

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/search (1).png"))); // NOI18N
        jLabel6.setText("Buscar:");
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, -1));

        jTProductos.setBackground(new java.awt.Color(0, 0, 0));
        jTProductos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTProductos.setForeground(new java.awt.Color(255, 255, 255));
        jTProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre", "ID", "Precio", "Stock"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTProductos.setCursor(new java.awt.Cursor(java.awt.Cursor.MOVE_CURSOR));
        jTProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTProductosMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTProductos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 621, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 516, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBAgregarStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAgregarStockActionPerformed
        String idProducto = jTFNumeroID.getText().trim();
        String cantidad = jTFCantidads.getText().trim();

        if (idProducto.isEmpty() || cantidad.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Llenar todos los campos");
            return;
        }

        int stock;

        try {
            stock = Integer.parseInt(cantidad);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Cantidad debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (stock <= 0) {
            JOptionPane.showMessageDialog(this, "Cantidad debe ser mayor que 0", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean encontrado = gestionProductos.agregar(idProducto, stock);

        if (encontrado) {
            JOptionPane.showMessageDialog(this, "Stock actualizado correctamente");
            actualizarTabla();
        } else {
            JOptionPane.showMessageDialog(this, "Producto no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
        }

        jTFNumeroID.setText("");
        jTFCantidads.setText("");
    }//GEN-LAST:event_jBAgregarStockActionPerformed

    private void jBEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBEliminarActionPerformed
    int filaSeleccionada = jTProductos.getSelectedRow();

    if (filaSeleccionada >= 0) {
        int confirm = JOptionPane.showConfirmDialog(this, "¿Deseas eliminar este producto?", "Confirmar", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Obtener los datos de la fila seleccionada
            String idProducto = tablaProductos.getValueAt(filaSeleccionada, 1).toString(); // Columna ID

            // Buscar el objeto Venta en la lista
            Venta productoAEliminar = null;
            for (Venta v : gestionProductos.getListaProducto()) {
                if (v.getIdProducto().equals(idProducto)) {
                    productoAEliminar = v;
                    break;
                }
            }

            if (productoAEliminar != null) {
                // Eliminar usando el método de GestionTienda
                gestionProductos.eliminarProducto(productoAEliminar);

                // Quitar de la tabla visual
                DefaultTableModel modelo = (DefaultTableModel) jTProductos.getModel();
                modelo.removeRow(filaSeleccionada);
                JOptionPane.showMessageDialog(this, "Producto eliminado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el producto.");
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Selecciona un producto para eliminar.");
    }
    }//GEN-LAST:event_jBEliminarActionPerformed

    private void jTFBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFBuscarActionPerformed

    private void jTProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTProductosMouseClicked
                                     
    int filaSeleccionada = jTProductos.getSelectedRow();

    if (filaSeleccionada >= 0) {
        // Obtener el ID del producto desde la tabla
        String id = tablaProductos.getValueAt(filaSeleccionada, 1).toString();

        // Mostrar el ID en el JTextField
        jTFNumeroID.setText(id);
    }

    }//GEN-LAST:event_jTProductosMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBAgregarStock;
    private javax.swing.JButton jBEliminar;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTFBuscar;
    private javax.swing.JTextField jTFCantidads;
    private javax.swing.JTextField jTFNumeroID;
    private javax.swing.JTable jTProductos;
    // End of variables declaration//GEN-END:variables

}
