package presentacion;

import entidad.Venta;
import negocio.GestionEmpleados;
import negocio.GestionProductos;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/*
 * Clase que representa la interfaz interna para gestionar el inventario de productos.
 * Esta clase se enfoca en la presentación (UI) y delega la lógica de negocio a las clases GestionTienda y GestionEmpleado.
 */
public class MenuInventario extends javax.swing.JInternalFrame {

    // Instancias de las clases que gestionan la lógica de tienda y empleados
    private GestionProductos gestionTienda = new GestionProductos();
    private GestionEmpleados gestionEmpleado = new GestionEmpleados();

    // Modelo de tabla para mostrar los productos en la interfaz
    private DefaultTableModel tablaProductos = new DefaultTableModel();
    
    TableRowSorter<DefaultTableModel> rowSorter = new TableRowSorter<>(tablaProductos);

    /*
     * Constructor que inicializa los componentes gráficos y carga los datos necesarios.
     */
    public MenuInventario() {
        initComponents();

        // Eliminar bordes y panel superior (barra de título) del JInternalFrame para diseño personalizado
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);

        // Definir las columnas que tendrá la tabla de productos
        String ids[] = {"Nombre", "ID", "Precio", "Stock"};
        tablaProductos.setColumnIdentifiers(ids);

        // Asignar el modelo de tabla al JTable de la interfaz
        jTProductos.setModel(tablaProductos);
         jTProductos.setRowSorter(rowSorter);

        // Cargar los productos almacenados desde archivo para poblar la lista
        gestionTienda.cargarProductos();

        // Actualizar la tabla gráfica con los productos cargados
        actualizarTabla();
    jTFBuscar.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) {
        filtrar();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        filtrar();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        filtrar();
    }

    private void filtrar() {
        String texto = jTFBuscar.getText();
        if (texto.trim().length() == 0) {
            rowSorter.setRowFilter(null);
        } else {
            // Filtrar solo por la primera columna (índice 0: "Nombre")
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto, 0));
        }
    }
});        
    }

    /*
     * Actualiza el contenido de la tabla de productos con la información actual.
     * Limpia las filas previas y agrega las filas correspondientes a cada producto en la lista.
     */
    private void actualizarTabla() {
        tablaProductos.setRowCount(0); // Eliminar todas las filas actuales

        // Recorrer la lista de productos y agregarlos como filas a la tabla
        for (Venta producto : gestionTienda.getListaProducto()) {
            Object[] fila = {
                producto.getNombreProducto(),
                producto.getIdProducto(),
                producto.getPrecio(),
                producto.getStock()
            };
            tablaProductos.addRow(fila);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTFNombrep = new javax.swing.JTextField();
        jTFStock = new javax.swing.JTextField();
        jTFPrecio = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jBRegistrar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jTFBuscar = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTProductos = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setMinimumSize(new java.awt.Dimension(930, 550));
        setPreferredSize(new java.awt.Dimension(930, 550));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Registrar producto", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Yu Gothic UI Semibold", 0, 18))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel2.setText("Nombre:");

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel4.setText("Precio:");

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel5.setText("Stock:");

        jTFNombrep.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jTFStock.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jTFPrecio.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jTFPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFPrecioActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/diskette.png"))); // NOI18N
        jButton2.setText("Guardar ");
        jButton2.setBorder(null);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/edit.png"))); // NOI18N
        jButton1.setText("Editar");
        jButton1.setBorder(null);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jBRegistrar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jBRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/agregar.png"))); // NOI18N
        jBRegistrar.setText("Registrar");
        jBRegistrar.setBorder(null);
        jBRegistrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jBRegistrar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBRegistrar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jBRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBRegistrarActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/search (1).png"))); // NOI18N
        jLabel6.setText("Buscar:");

        jTFBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFBuscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jBRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTFBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTFStock, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTFPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTFNombrep, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(94, 94, 94))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jTFNombrep, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jTFPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jTFStock, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jTFBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addComponent(jBRegistrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 520));

        jTProductos.setBackground(new java.awt.Color(0, 0, 0));
        jTProductos.setForeground(new java.awt.Color(255, 255, 255));
        jTProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre", "ID", "Precio", "Stock"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTProductosMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTProductos);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, 530, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBRegistrarActionPerformed
// Obtener valores de los campos de texto, eliminando espacios en blanco al inicio y fin
    String nombreProducto = jTFNombrep.getText().trim();
    String precio = jTFPrecio.getText().trim();
    String stock = jTFStock.getText().trim();

// Validar que no haya campos vacíos
    if (nombreProducto.isEmpty() || precio.isEmpty() || stock.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Llenar todos los campos");
    return; // Detener ejecución si hay campos vacíos
    }

    double preciop;
    int stockProducto;

// Validar que precio y stock sean números válidos
    try {
    preciop = Double.parseDouble(precio);
    stockProducto = Integer.parseInt(stock);
    } catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser valores numéricos válidos", "Error", JOptionPane.ERROR_MESSAGE);
    return;
    }

// Validar que precio y cantidad sean mayores que cero
    if (preciop <= 0 || stockProducto <= 0) {
    JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser mayores que 0", "Error", JOptionPane.ERROR_MESSAGE);
    return;
    }

// Generar ID para el producto con formato 4 dígitos (ej: 0001, 0002...)
    String idGenerado = String.format("%04d", gestionTienda.getListaProducto().size() + 1);

// Crear nuevo objeto Venta con los datos ingresados
    Venta venta = new Venta(nombreProducto, idGenerado, preciop, stockProducto);

// Verificar si el producto ya existe (por ID o nombre)
// Si retorna false, significa que ya existe y muestra mensaje internamente

// Guardar producto en archivo para persistencia
    gestionTienda.guardarProductos(venta);

// Mostrar mensaje de éxito al usuario
    JOptionPane.showMessageDialog(this, "Producto agregado al inventario");

// Actualizar la tabla en la interfaz (asumo que tienes método para eso)
    actualizarTabla();

// Limpiar campos de entrada para nueva captura
    jTFNombrep.setText("");
    jTFPrecio.setText("");
    jTFStock.setText("");

    }//GEN-LAST:event_jBRegistrarActionPerformed

    private void jTFPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFPrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFPrecioActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int filaSeleccionada = jTProductos.getSelectedRow(); // fila seleccionada

        if (filaSeleccionada >= 0) {
            jTFNombrep.setText(tablaProductos.getValueAt(filaSeleccionada, 0).toString());
            jTFPrecio.setText(tablaProductos.getValueAt(filaSeleccionada, 2).toString());
            jTFStock.setText(tablaProductos.getValueAt(filaSeleccionada, 3).toString());
        }     
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTProductosMouseClicked

    }//GEN-LAST:event_jTProductosMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
int filaSeleccionada = jTProductos.getSelectedRow();
if (filaSeleccionada >= 0) {
    String nombreProducto = jTFNombrep.getText().trim();
    String precio = jTFPrecio.getText().trim();
    String stock = jTFStock.getText().trim();
    String codigo = tablaProductos.getValueAt(filaSeleccionada, 0).toString();

    double preciop;
    int stockProducto;

    try {
        preciop = Double.parseDouble(precio);
        stockProducto = Integer.parseInt(stock);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser valores numéricos válidos", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (preciop <= 0 || stockProducto <= 0) {
        JOptionPane.showMessageDialog(this, "Precio y cantidad deben ser mayores que 0", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Actualizar visualmente en la tabla
    tablaProductos.setValueAt(nombreProducto, filaSeleccionada, 0);
    tablaProductos.setValueAt(precio, filaSeleccionada, 2);
    tablaProductos.setValueAt(stock, filaSeleccionada, 3);


    JOptionPane.showMessageDialog(null, "¡Producto actualizado correctamente!");
} else {
    JOptionPane.showMessageDialog(null, "Selecciona una fila primero.");
}

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTFBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFBuscarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBRegistrar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTFBuscar;
    private javax.swing.JTextField jTFNombrep;
    private javax.swing.JTextField jTFPrecio;
    private javax.swing.JTextField jTFStock;
    private javax.swing.JTable jTProductos;
    // End of variables declaration//GEN-END:variables

}
