
package entidad;

import javax.swing.JOptionPane;

public class Venta extends Producto implements IVentas{
    private Cliente cliente=new Cliente();
    private int cantidad;
    private double total;

    public Venta(String nombrep, String id, double precio, int stock) {
        super(nombrep, id, precio, stock);
        this.cantidad = cantidad;
        this.total = total;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    @Override
    public void calcularPrecio() {
        this.total = super.getPrecio() * cantidad;
    }

    // Método para procesar el pago (descuenta del saldo del cliente)
    public boolean pago() {
        calcularPrecio(); // Asegurarse de que el total esté calculado
        
        if (cliente.getSaldo() >= total) {
            cliente.setSaldo(cliente.getSaldo() - total);
            JOptionPane.showMessageDialog(null,"Pago exitoso. Saldo restante: " + cliente.getSaldo());
            return true;
        } else {
            JOptionPane.showMessageDialog(null,"Saldo insuficiente. Saldo actual: " + cliente.getSaldo());
            return false;
        }
    }
}
