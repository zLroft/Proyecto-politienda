
package entidad;

public interface IVentas {
    void calcularPrecio();
    
}
