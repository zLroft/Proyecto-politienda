
package entidad;

public class Producto {
    private String nombreProducto;
    private String idProducto;
    private double precio;
    private int stock;

    public Producto(String nombreProducto, String idProducto, double precio, int stock) {
        this.nombreProducto = nombreProducto;
        this.idProducto = idProducto;
        this.precio = precio;
        this.stock = stock;
    }

    public Producto() {
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
    public void agregarStock(int cantidad){
        stock=stock+cantidad;
    }
    
    public boolean reducirStock(int cantidad){
        if (cantidad <= stock) {
            stock -= cantidad;
            return true;
        }
        return false;        
    }

    @Override
    public String toString() {
        return "Producto" 
                + "\nNombre: " + nombreProducto 
                + "\nCodigo: " + idProducto 
                + "\nPrecio: " + precio 
                + "\nStock: " + stock 
                + "\n";
    }
 
}

