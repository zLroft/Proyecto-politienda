
package entidad;

public class Empleado {
    private String nombreEmpleado;
    private String cedulaEmpleado;
    private String usuarioEmpleado;
    private String contraseniaEmpleado;

    public Empleado(String nombre, String cedula, String usuario, String contra) {
        this.nombreEmpleado = nombre;
        this.cedulaEmpleado = cedula;
        this.usuarioEmpleado = usuario;
        this.contraseniaEmpleado = contra;
    }

    public Empleado() {
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public String getCedulaEmpleado() {
        return cedulaEmpleado;
    }

    public void setCedulaEmpleado(String cedulaEmpleado) {
        this.cedulaEmpleado = cedulaEmpleado;
    }

    public String getUsuarioEmpleado() {
        return usuarioEmpleado;
    }

    public void setUsuarioEmpleado(String usuarioEmpleado) {
        this.usuarioEmpleado = usuarioEmpleado;
    }

    public String getContraseniaEmpleado() {
        return contraseniaEmpleado;
    }

    public void setContraseniaEmpleado(String contraseniaEmpleado) {
        this.contraseniaEmpleado = contraseniaEmpleado;
    }
 
    public boolean login(String usuario, String contrasena) {
        return this.usuarioEmpleado.equals(usuario) && this.contraseniaEmpleado.equals(contrasena);
    }
    
    @Override
    public String toString() {
        return "Empleado" 
                + "\nNombre: " + nombreEmpleado 
                + "\nCedula: " + cedulaEmpleado;
    }
    
}

