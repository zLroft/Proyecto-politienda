
package entidad;

import presentacion.Login;

public class Principal {

    public static void main(String[] args) {
        Login login=new Login();
        login.setVisible(true);
    }
    
}
