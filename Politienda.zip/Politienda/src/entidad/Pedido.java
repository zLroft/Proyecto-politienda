
package entidad;

import java.util.Date;
import java.util.List;

public class Pedido {
    private String codigoPedido;
    private List<Producto> productos;  // o lista de detalles
    private double total;
    private Date fecha;
    private String cedulaCliente;

    public Pedido(String codigoPedido, List<Producto> productos, double total, Date fecha, String cedulaCliente) {
        this.codigoPedido = codigoPedido;
        this.productos = productos;
        this.total = total;
        this.fecha = fecha;
        this.cedulaCliente = cedulaCliente;
    }

    public Pedido() {
    }

    public String getCodigoPedido() {
        return codigoPedido;
    }

    public void setCodigoPedido(String codigoPedido) {
        this.codigoPedido = codigoPedido;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getCedulaCliente() {
        return cedulaCliente;
    }

    public void setCedulaCliente(String cedulaCliente) {
        this.cedulaCliente = cedulaCliente;
    }
}

