
package negocio;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import entidad.Cliente;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class GestionClientes {

/*
  Clase que gestiona las operaciones relacionadas con los clientes.
  Responsable de almacenar, autenticar, cargar y guardar clientes. 
 */
    
    Gson gson=new Gson();

    // Lista interna de clientes en memoria
    private List<Cliente> listaClientes;

    // Constructor inicializa la lista
    public GestionClientes() {
        this.listaClientes = new ArrayList<>();
    }

    // Getter para obtener la lista completa de clientes
    public List<Cliente> getListaClientes() {
        return listaClientes;
    }

    // Setter para reemplazar la lista completa
    public void setListaClientes(List<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }

    /*
      Autentica un cliente buscando usuario y contraseña.
      usuario Usuario a autenticar
      contrasena Contraseña correspondiente
      Cliente autenticado o null si no existe
     */


    /*
      Agrega un cliente nuevo a la lista en memoria.
      cliente Cliente a agregar
     */
    public void agregarCliente(Cliente cliente) {
        listaClientes.add(cliente);
    }

    /*
      Retorna una representación en String del primer cliente de la lista. 
      String del cliente o null si no hay clientes
     */
    public String mostrarCliente() {
        if (!listaClientes.isEmpty()) {
            return listaClientes.get(0).toString();
        }
        return null;
    }

    /*
      Método para simular el pago de un pedido.
      Verifica si algún cliente tiene saldo suficiente para pagar.
      Si es así, guarda todos los clientes actualizados.
      Si no, muestra un mensaje de saldo insuficiente.
     */
    public void pagoPedido(double precio) {
        for (Cliente c : listaClientes) {
            if (precio < c.getSaldo()) {
                // Aquí debería descontar el saldo, no solo guardar
                
                return; // Sale si encontró cliente con saldo suficiente
            }
        }
        JOptionPane.showMessageDialog(null, "Saldo insuficiente");
    }
    
    public void actualizarCliente(Cliente actualizado) {
    cargarClientes();

    for (int i = 0; i < listaClientes.size(); i++) {
        if (listaClientes.get(i).getCedulaCliente().equals(actualizado.getCedulaCliente())) {
            listaClientes.set(i, actualizado);
            break;
        }
    }

        guardarClientes(actualizado);
}


    /*
      Muestra el saldo de un cliente formateado con símbolo $
      c Cliente del cual mostrar saldo
      Saldo en String con símbolo $
     */
    public String mostrarSaldo(Cliente c) {
        return String.format("%.2f$", c.getSaldo());
    }
    
    public void guardarClientes(Cliente cliente) {
    // Cargar clientes previamente guardados
    cargarClientes();

    // Agregar nuevo cliente
    agregarCliente(cliente);

    // Guardar la lista actualizada
    try (FileWriter writer = new FileWriter("Lista de clientes.json")) {
        gson.toJson(listaClientes, writer);
    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error al guardar clientes: " + e.getMessage());
        e.printStackTrace();
    }
    }


    public void cargarClientes() {
    File archivo = new File("Lista de clientes.json");
    if (!archivo.exists()) {
        // Si no existe el archivo, inicializa una lista vacía
        listaClientes = new java.util.ArrayList<>();
        System.out.println("Archivo de clientes no encontrado. Se inicializó una lista vacía.");
        return;
    }

    try (FileReader reader = new FileReader(archivo)) {
    Type tipoLista = new TypeToken<List<Cliente>>() {}.getType();
    listaClientes = gson.fromJson(reader, tipoLista);
        System.out.println("Clientes cargados correctamente desde 'Lista de clientes.json'");
    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error al cargar clientes: " + e.getMessage());
        e.printStackTrace();
    }
    }
    }

