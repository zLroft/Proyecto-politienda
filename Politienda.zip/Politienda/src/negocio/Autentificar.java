package negocio;

import entidad.Cliente;
import entidad.Empleado;

public class Autentificar {
    private GestionClientes gestionClientes;
    private GestionEmpleados gestionEmpleados;

    public Autentificar(GestionClientes gestionClientes, GestionEmpleados gestionEmpleados) {
        this.gestionClientes = gestionClientes;
        this.gestionEmpleados = gestionEmpleados;
    }


    public Cliente autenticarCliente(String usuario, String contrasena) {
        for (Cliente c : gestionClientes.getListaClientes()) {
            if (c.getUsuarioCliente().equals(usuario) &&
                c.getContraseniaCliente().equals(contrasena)) {
                return c;
            }
        }
        return null;
    }
    
    public Empleado autenticarEmpleado(String usuario, String contrasena) {
        for (Empleado e : gestionEmpleados.getListaEmpleados()) {
            if (e.getUsuarioEmpleado().equals(usuario) && 
                    e.getContraseniaEmpleado().equals(contrasena)) {
                return e;
            }
        }
        return null;
    }
}

