
package negocio;

import entidad.Cliente;
import entidad.Empleado;

public class Sesion {
    
    public static Empleado empleadoLogueado;
    public static Cliente clienteLogeado;

}
