
package negocio;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import entidad.Empleado;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/*
  Clase que gestiona las operaciones relacionadas con los empleados.
  Responsable de almacenar, autenticar, cargar y guardar empleados.  
 */
public class GestionEmpleados {
    
    Gson gson=new Gson();

    // Lista interna de empleados en memoria
    private List<Empleado> listaEmpleados;

    // Constructor que inicializa la lista
    public GestionEmpleados() {
        this.listaEmpleados = new ArrayList<>();
    }

    /*
      Método para autenticar empleado dado un usuario y contraseña.
      usuario Nombre de usuario del empleado
      contrasena Contraseña del empleado
      Empleado autenticado o null si no se encuentra coincidencia
     */


    /*
      Agrega un nuevo empleado a la lista en memoria.
      empleado Empleado a agregar
     */
    public void agregarEmpleado(Empleado empleado) {
        listaEmpleados.add(empleado);
    }

    /*
     Devuelve la lista completa de empleados en memoria.
     return Lista de empleados
     */
    public List<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }

    /*
      Muestra la información básica de un empleado en formato legible.
       e Empleado a mostrar
       String con datos del empleado
     */
    public String mostrarEmpleado(Empleado e) {
        return "Nombre: " + e.getNombreEmpleado() + "\n" +
               "Usuario: " + e.getUsuarioEmpleado() + "\n" +
               "Cédula: " + e.getCedulaEmpleado() + "\n";
    }

    /*
      Guarda un empleado nuevo en archivo "Empleados.csv" .
     Formato CSV: nombreEmpleado, cedulaEmpleado, usuarioEmpleado, contraseniaEmpleado
      empleado Empleado a guardar
     */
    public void guardarEmpleados(Empleado empleado) {
            // Cargar clientes previamente guardados
     cargarEmpleados();

    // Agregar nuevo cliente
    agregarEmpleado(empleado);
        try (FileWriter writer = new FileWriter("Lista de empleados.json")) {
            gson.toJson(listaEmpleados, writer);
            JOptionPane.showMessageDialog(null, "Lista de clientes guardada correctamente en 'Lista de empleados.json'");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar empleados: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /*
      Carga empleados desde el archivo "Empleados.csv" y los almacena en memoria.
      Limpia la lista antes de cargar.
      Corrige el orden y número de campos para coincidir con el guardado.
     */
    public void cargarEmpleados() {
    File archivo = new File("Lista de empleados.json");
    if (!archivo.exists()) {
        // Si no existe el archivo, inicializa una lista vacía
        listaEmpleados = new java.util.ArrayList<>();
        System.out.println("Archivo de empleados no encontrado. Se inicializó una lista vacía.");
        return;
    }

    try (FileReader reader = new FileReader(archivo)) {
    Type tipoLista = new TypeToken<List<Empleado>>() {}.getType();
    listaEmpleados = gson.fromJson(reader, tipoLista);
        System.out.println("Clientes cargados correctamente desde 'Lista de empleados.json'");
    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error al cargar empleados: " + e.getMessage());
        e.printStackTrace();
    }
    }

}
