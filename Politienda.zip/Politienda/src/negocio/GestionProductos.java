
package negocio;

import entidad.Venta;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import entidad.Venta;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

/*
  Clase que gestiona la lógica relacionada con los productos (ventas).
  Responsable de almacenar, modificar, eliminar, cargar y guardar productos.
 */
public class GestionProductos {
    
    Gson gson=new Gson();

    // Lista interna que almacena los productos en memoria
    private List<Venta> listaProducto;

    // Constructor que inicializa la lista
    public GestionProductos() {
        this.listaProducto = new ArrayList<>();
    }

    // Getter para la lista de productos
    public List<Venta> getListaProducto() {
        return listaProducto;
    }

    // Setter para la lista de productos
    public void setListaProducto(List<Venta> listaProducto) {
        this.listaProducto = listaProducto;
    }

    /*
      Agrega un nuevo producto a la lista.
      venta Producto a agregar
     */
    public void agregarProducto(Venta venta) {
        listaProducto.add(venta);
    }

    /*
      Devuelve un String con la representación de todos los productos.
       String con la info concatenada de todos los productos
     */
    public String mostrarProductos() {
        StringBuilder salida = new StringBuilder();
        for (Venta v : listaProducto) {
            salida.append(v.toString()).append("\n");
        }
        return salida.toString();
    }

    /*
      Verifica que no existan productos con mismo ID o nombre.
      Si encuentra coincidencia muestra mensaje de alerta.
      venta Producto a validar
       true si no hay conflictos, false si ya existe
     */
    public boolean verificarExistencia(Venta venta) {
        for (Venta v : listaProducto) {
            if (v.getIdProducto().equals(venta.getIdProducto())) {
                JOptionPane.showMessageDialog(null, "El ID ya existe");
                return false;
            }
            if (v.getNombreProducto().equalsIgnoreCase(venta.getNombreProducto())) {
                JOptionPane.showMessageDialog(null, "El nombre ya existe");
                return false;
            }
        }
        return true;
    }

    /*
      Elimina un producto de la lista y guarda los cambios en archivo.
      venta Producto a eliminar
     */
    public void eliminarProducto(Venta venta) {
    // Cargar productos actualizados desde el archivo (opcional, si no lo haces ya al inicio)
    cargarProductos();

    // Eliminar de la lista en memoria
    listaProducto.remove(venta);

    // Guardar toda la lista actualizada (sin el producto eliminado)
        guardarProductos(venta);
    }

    /*
      Reduce el stock de un producto identificado por id en la cantidad especificada.
      Guarda los cambios en archivo.
       id ID del producto
       cantidad Cantidad a reducir
       true si producto existe y stock fue reducido, false si no existe
     */
    public boolean reducir(String id, int cantidad) {
        for (Venta v : listaProducto) {
            if (v.getIdProducto().equals(id)) {
                v.reducirStock(cantidad);
                guardarProductos(v);
                return true;
            }
        }
        return false;
    }

    /*
      Aumenta el stock de un producto identificado por id en la cantidad especificada.
       id ID del producto
       cantidad Cantidad a agregar
       true si producto existe y stock fue incrementado, false si no existe
     */
    public boolean agregar(String id, int cantidad) {
        for (Venta v : listaProducto) {
            if (v.getIdProducto().equals(id)) {
                v.agregarStock(cantidad);
                guardarProductos(v);
                return true;
            }
        }
        return false;
    }
    
public void guardarProductos(Venta nuevoProducto) {
    // Cargar lista actual
    cargarProductos();

    // Reemplazar el producto si ya existe
    boolean reemplazado = false;
    for (int i = 0; i < listaProducto.size(); i++) {
        if (listaProducto.get(i).getIdProducto().equals(nuevoProducto.getIdProducto())) {
            listaProducto.set(i, nuevoProducto);
            reemplazado = true;
            break;
        }
    }

    // Si no estaba, lo agrega como nuevo
    if (!reemplazado) {
        listaProducto.add(nuevoProducto);
    }

    // Guardar lista completa actualizada
    try (Writer writer = new FileWriter("Lista de productos.json")) {
        gson.toJson(listaProducto, writer);
    } catch (IOException e) {
        System.out.println("Error al guardar productos: " + e.getMessage());
    }
}


    public void cargarProductos() {
    File archivo = new File("Lista de productos.json");
    if (!archivo.exists()) {
        listaProducto = new ArrayList<>(); // No existe, así que lista vacía
        return;
    }

    try (FileReader reader = new FileReader(archivo)) {
        Type tipoLista = new TypeToken<List<Venta>>() {}.getType();
        listaProducto = gson.fromJson(reader, tipoLista);
        if (listaProducto == null) {
            listaProducto = new ArrayList<>();
        }
    } catch (IOException e) {
        e.printStackTrace();
        listaProducto = new ArrayList<>();
    }
    }

}
