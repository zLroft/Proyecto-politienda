
package negocio;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import entidad.Pedido;

public class GestionPedidos {

    private List<Pedido> listaPedidos;
    Gson gson = new Gson();

    public GestionPedidos() {
        this.listaPedidos = new ArrayList<>();
    }

    public void agregarPedido(Pedido pedido) {
        listaPedidos.add(pedido);
    }

    public List<Pedido> getListaPedidos() {
        return listaPedidos;
    }
    
public List<Pedido> obtenerPedidosPorCedula(String cedula) {
    cargarPedidos(); // Asegura que la lista esté actualizada
    List<Pedido> pedidosCliente = new ArrayList<>();
    for (Pedido p : listaPedidos) {
        if (p.getCedulaCliente().equals(cedula)) {
            pedidosCliente.add(p);
        }
    }
    return pedidosCliente;
}

    public void cancelarPedido(Pedido pedido){
        listaPedidos.remove(pedido);
    }

    public void guardarPedidos(Pedido pedido) {
        cargarPedidos();
        agregarPedido(pedido);
        try (FileWriter writer = new FileWriter("lista_pedidos.json")) {
            gson.toJson(listaPedidos, writer);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar pedidos: " + e.getMessage());
        }
    }
    
    public void guardarTodosLosPedidos(Pedido pedido) {
        cargarPedidos();
        cancelarPedido(pedido);
    try (FileWriter writer = new FileWriter("lista_pedidos.json")) {
        gson.toJson(listaPedidos, writer);
    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error al guardar pedidos: " + e.getMessage());
    }
}

    public void cargarPedidos() {
        try (FileReader reader = new FileReader("lista_pedidos.json")) {
            Type tipoLista = new TypeToken<List<Pedido>>() {}.getType();
            listaPedidos = gson.fromJson(reader, tipoLista);

            if (listaPedidos == null) {
                listaPedidos = new ArrayList<>();
            }

        } catch (IOException e) {
            listaPedidos = new ArrayList<>();
            System.err.println("No se pudo cargar pedidos: " + e.getMessage());
        }
    }
}

