﻿using System.Collections.Generic;
using System.Text;
using Entidad;

namespace Negocio
{
    public class GestionTienda
    {
        private List<Producto> listaProductos = new List<Producto>();

        public void AgregarProducto(string nombre, string id, double precio, int stock)
        {
            listaProductos.Add(new Producto(nombre, id, precio, stock));
        }

        public string MostrarProductos()
        {
            StringBuilder salida = new StringBuilder();
            foreach (Producto p in listaProductos)
            {
                salida.AppendLine(p.ToString());
            }
            return salida.ToString();
        }

        public List<Producto> ObtenerProductos()
        {
            return listaProductos;
        }
    }
}
