﻿using System.Collections.Generic;
using Entidad;

namespace Negocio
{
    public class GestionEmpleado
    {
        private List<Empleado> empleados;

        public GestionEmpleado()
        {
            empleados = new List<Empleado>
            {
                new Empleado("Juan", "1723456789", "juan", "1234")
            };
        }

        public Empleado Autenticar(string usuario, string contrasena)
        {
            foreach (Empleado e in empleados)
            {
                if (e.Usuario == usuario && e.Contrasena == contrasena)
                {
                    return e;
                }
            }
            return null;
        }

        public List<Empleado> ObtenerEmpleados()
        {
            return empleados;
        }
    }
}


