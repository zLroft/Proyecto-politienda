﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaPresentacion;
using Entidad;
using Negocio;
namespace CapaPresentacion
{
    public partial class login : Form
    {

        private GestionEmpleado gestionEmpleado = new GestionEmpleado();

       

       
        public login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {

            string usuario = txtUsuario.Text;
            string contrasena = txtContraseña.Text;

            if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(contrasena))
            {
                MessageBox.Show("Llenar los campos");
                return;
            }

            Empleado emp = gestionEmpleado.Autenticar(usuario, contrasena);
            if (emp != null)
            {
                MessageBox.Show("Bienvenido " + emp.Nombre);
                Administrar formAdmin = new Administrar();
                formAdmin.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Credenciales incorrectas", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
