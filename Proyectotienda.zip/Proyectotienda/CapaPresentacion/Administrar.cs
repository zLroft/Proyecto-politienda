﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocio;

namespace CapaPresentacion
{
    public partial class Administrar : Form
    {
        private GestionTienda gestionTienda = new GestionTienda();

        
     
        public Administrar()
        {
            InitializeComponent();
        }

        private void Administrar_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnAgregarProducto_Click_1(object sender, EventArgs e)
        {

            string nombre = txtNombre.Text.Trim();
            string id = txtID.Text.Trim();
            string precioText = txtPrecio.Text.Trim();
            string stockText = txtStock.Text.Trim();

            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(id) ||
                string.IsNullOrWhiteSpace(precioText) || string.IsNullOrWhiteSpace(stockText))
            {
                MessageBox.Show("Llenar todos los campos.");
                return;
            }

            if (!double.TryParse(precioText, out double precio) || !int.TryParse(stockText, out int stock) || precio <= 0 || stock < 0)
            {
                MessageBox.Show("Datos inválidos.");
                return;
            }

            try
            {
                gestionTienda.AgregarProducto(nombre, id, precio, stock);
                MessageBox.Show("Producto agregado con éxito.");
                txtInventario.Text = gestionTienda.MostrarProductos();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar producto: " + ex.Message);
            }

        }



        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtID.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
            txtNombre.Focus();
        }
    }
}
