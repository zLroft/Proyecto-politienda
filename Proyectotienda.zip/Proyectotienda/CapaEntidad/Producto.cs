﻿// Entidad/Producto.cs
namespace Entidad
{
    public class Producto
    {
        public string Nombre { get; set; }
        public string Codigo { get; set; }
        public double Precio { get; set; }
        public int Stock { get; set; }

        public Producto() { }

        public Producto(string nombre, string codigo, double precio, int stock)
        {
            Nombre = nombre;
            Codigo = codigo;
            Precio = precio;
            Stock = stock;
        }

        public void ReducirStock(int cantidad)
        {
            if (cantidad > 0 && cantidad <= Stock)
            {
                Stock -= cantidad;
            }
        }

        public override string ToString()
        {
            return $"Producto: {Nombre}\nCódigo: {Codigo}\nPrecio: {Precio:C}\nStock: {Stock}\n";
        }
    }
}
