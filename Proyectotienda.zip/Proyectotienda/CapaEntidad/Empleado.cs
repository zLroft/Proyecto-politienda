﻿// Entidad/Empleado.cs
namespace Entidad
{
    public class Empleado
    {
        public string Nombre { get; set; }
        public string Cedula { get; set; }
        public string Usuario { get; set; }
        public string Contrasena { get; set; }

        public Empleado() { }

        public Empleado(string nombre, string cedula, string usuario, string contrasena)
        {
            Nombre = nombre;
            Cedula = cedula;
            Usuario = usuario;
            Contrasena = contrasena;
        }

        public bool Login(string usuario, string contrasena)
        {
            return Usuario == usuario && Contrasena == contrasena;
        }

        public override string ToString()
        {
            return $"Empleado: {Nombre}\nCédula: {Cedula}";
        }
    }
}
